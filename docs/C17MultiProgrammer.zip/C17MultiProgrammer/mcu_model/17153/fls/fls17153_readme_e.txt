    FLASH READ/WRITE PROGRAMS FOR S1C17153(FLS17153) 

    NJul. 31, 2015

    Copyright (C) SEIKO EPSON CORP. 2015

Contents
================
1) Summary
2) File configuration
3) About use in GNU17 Ver.2.x
4) About use in GNU17 Ver.3.x
5) Error code
6) Others
7) Revision history
================


1) Summary

   It explains the use of FLS program. 

   The FLS program is a program to perform data writing / erasing
   for internal flash memory on debugger(GDB).
   This model is a mask ROM. Therefore, system evaluation uses S1C17153.


2) File configuration

   The configuration of this directory is as follows.

   17153
     +  fls
         +  fls17153.elf         FLS program file for S1C17153
         +  fls17153_readme_j.txt    Readme file(Japanese)
         +  fls17153_readme_e.txt    Readme file(English)


3) About use in GNU17 Ver.2.x

   3-1)  Connection of S5U1C17001H(ICDmini) and user's target board
      When flash memory is erasure or writing, it is necessary to supply 
      the following voltage for flash programming to S1C17153. 
      * Erasure     7.5V
      * Writing     7.0V
      The voltage for flash programming can be controlled 
      by S5U1C17001C(since GNU17 ver2.0) and S5U1C17001H2(ICDmini Ver2.0). 

      Please the target where S1C17153 have on board turn on power in the following way. 
      (1) It power on target board.
      (2) It power on S5U1C17001H2.
      (3) The supply of voltage for flash programming is set.
          The SW8 of S5U1C17001H2 is turned on.
      (4) The RESET/START button of S5U1C17001H2 is push.
      Please refer to "S5U1C17001H2 User Manual(ICDmini Ver2.0)" for the connection of S5U1C17001H2 and target board.

      *Notes
       Please supply voltage for flash programming while it supplies power to the target.


   3-2)  Executing flash memory erasure/writing command

       S5U1C17001H2 supply the voltage for the glash programming. 
       When you load a program in flash memory with gdb, perform it in the following procedures.

      ;FLS program setting

      file fls17153.elf
      target icd usb 
      load fls17153.elf
      
      ;Erase

      c17 fls 0x8000 0xbfff FLASH_PREPROGRAM FLASH_LOAD
      c17 flv 7.0
      c17 fle 0x8000 1 4
      c17 flvs
      c17 fls 0x8000 0xbfff FLASH_SECTORERASE FLASH_LOAD 128
      c17 flv 7.5
      c17 fle 0x8000 1 4
      c17 flvs

      ;User program is write

      file ***.elf
      target icd usb
      c17 flv 7.0
      load ***.psa
      c17 flvs 


   3-3)  The flash memory erasure/writing command is generated from the template
      The flash memory erasure/writing command can be generated from the model the following procedures. 
      GNU17 IDE -> Project of object -> Properties -> GNU17 GDB Commands ->
      "Create commands from template" -> "Use the command file that depends on machine model" -> Overwrite

      Please change the part of "xxx" such as xxx.elf and xxx.par and xxx.psa to the project name of the object. 


4) About use in GNU17 Ver.3.x

  4-1)    Connection of S5U1C17001H3(ICDmini3) and target
        Please connect S5U1C17001H3 with the target.
        Please refer to "S5U1C17001H3 User Manual(ICDmini Ver3.0)" for the connection
        procedure.


  4-2)    gdbmini3.ini modification and execution
        Please describe following commands in the debugger (GDB) command file
        "gdbmini3.ini", and execute it.
            - "c17 model_path" and "c17 model" command to specify this directory.
            - "load" command to execute erasing and writing.
        The "gdbmini3.ini" examples are shown below.
        Please refer to "S5U1C17001C Manual(C Compiler Package)" for the debugger
        command, and refer to 4-3) for detail options of "c17 model" command.

        [Ex. 1] VP pin and TARGET_VCC_IN pin are connected.

        ; This directory and the target model are specified.
        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17153
        ; The control of the target begins.
        target icd icdmini3
        ; Flash memory is erased, and a new program is written.
        load
        ; The program will stop at main after execution.
        thbreak main

        [Ex. 2] TARGET_VCC_IN pin is not connected.
        When TARGET_VCC_IN pin is not connected, please specify optional NOVCCIN for
        the c17 model command.

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17153@NOVCCIN
        target icd icdmini3
        load
        thbreak main

        [Ex. 3] TARGET_VCC_IN pin is not connected and resetting target CPU is prohibited.
        To specify two or more options, please delimit them by ",".

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17153@NOVCCIN,NORESET
        target icd icdmini3
        load
        thbreak main


  4-3)    [Detail] options of the c17 model command.
        S1C17153 model supports following options.

    NOVCCIN     Specifies that TARGET_VCC_IN pin of ICDmini3 is not connected.
                [Operation when omitted]
                ICDmini3 communicates with Target CPU by TARGET_VCC_IN voltage level.
                Connection of TARGET_VCC_IN pin and target power suply is necessary.
        Parameter       None

    FLS         Spefifies the FLS proram file.
                [Operation when omitted]
                Standard FLS program file is used.
        Parameter       FLS program file name (*.saf)
        Example         FLS=fwr17153v11.saf    ; Standard FLS program is specified.

    NOREAD      Prohibits the comparison between the writing data and the data written
                in the flash memory.
                [Operation when omitted]
                The writing data is compared with the data written in the flash memory,
                and writing is omitted when equals.
        Parameter       None

    NOWRITE     Prohibits writing in the flash memory.
                [Operation when omitted]
                When the load command of the debugger is executed, data is written in
                the flash memory, except when the writing data equals the written data
                in the flash memory.
        Parameter       None

    NOERASE     Prohibits erasing of the flash memory.
                [Operation when omitted]
                The erase is executed before data is written in the flash memory.
        Parameter       None

    NORESET     Prohibits resetting target CPU when debug begins.
                [Operation when omitted]
                When debug begins, tareget CPU is reset.
        Parameter       None

    VPP         Sets the erasing and the writing voltage of the flash memory.
                [Operation when omitted]
                The voltage is applied according to the MCU specification 
        Parameter       7.5[V] or 7.0[V]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         VPP=7.5                 ; VPP is 7.5V. 

    SECTOR      Specifies the range of the erasing and writing sectors.
                [Operation when omitted]
                All sectors are included within the range.
        Parameter       begin-end
                        Please set sector number+1 to the value of the begin and the end.
                        Effective sector numbers are defined by another material.
                        When invalid numbers are specified, this option is considered
                        to have been omitted.
        Example         SECTOR=1-10             ; The range of the erasing and writing
                                                ; is from sector 0 to 9.

    BREAKWAIT   Specifies the maximum waiting time [msec] to terminate tareget execution.
                [Operation when omitted]
                Default value (3000msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         BREAKWAIT=3000          ; 3000 [msec] is set.

    TIMEOUT     Specifies the maximum waiting time [msec] when ICDmini3 communicates with
                target MCU.
                [Operation when omitted]
                Default value (10msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         TIMEOUT=10              : 10 [msec] is set.

5) Error code

   Error codes of the FLS program mean as follows.

      0x0 : Finished normally.
      0x1 : Failed in writing / erasure by a verification error.
            Read data from address corresponding to writing / erasure, and compare it 
            with data attempted to write / erase, and the error code returns 
            when they are different.
            At the erasure, compare the data with 0xffff. 
      0x3 : Argument error 1 of erasure command.
      0x4 : Argument error 2 of erasure command. 
      0x5 : Flash memory top address is wrong.
            The error code returns when given top address of flash memory is different
            from actual top address of the flash memory. 


6) Others

   6-1)  Copyright
       Except for samples, SEIKO EPSON CORP. holds copyright on all files.
       Don't copy, distribute, or modify copyrighted works without permission. 
       Usage of this program is limited to development or design of product 
       which uses S1C17.

   6-2)  Version up
       Please note that contents may change without prior notice.
       

7) Revision history
   Ver 1.0     Sep. 10, 2012        - Newly made.
   Ver 1.1     Nov. 02, 2012        - Description of the contents of control was changed.
   Ver 1.2     Jul. 31, 2015        - Add about use in GNU17 Ver.3.x.

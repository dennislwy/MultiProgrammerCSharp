    FLASH READ/WRITE PROGRAMS FOR S1C17501(FLS17501) 

        Jul. 31, 2015

        Copyright (C) SEIKO EPSON CORP. 2015


1. Summary

	The fls program of this directory works on the internal RAM, which is a program
	to perform data programing/erasing for the S1C17501 internal flash memory on gdb.


2. File configuration

	The configuration of this directory is as follows.

   S1C17501
     +  fls17501.elf    FLS program file for S1C17501
     +  fwr17501v10.saf	Motorola S3 format file for flash-writer(ICD firmware ver1.0)
     +  fwr17501v11.saf	Motorola S3 format file for flash-writer(Since ICD firmware ver1.1)
     +  readme_j.txt    Readme file(Japanese)
     +  readme_e.txt    Readme file(English)


2. Summary of the flash memory

   The summary of the S1C17501 internal flash memory is as follows.

	Number of sectors :  128 sectors (Size of sector : 1KByte)
	Memory size       :  128KB(64K * 16bit)
	Erasure unit      :  chip or sector unit
	writing unit      :  word (16bit) unit
	Read cycle        :  1-8 cycles
	Operation voltage :  read            3.0V - 3.6V
	                     Erasure/writing 3.0V - 3.6V

   Note: Please refer to "S1C17501 Technical Manual" for Power supply voltage of S1C17501.

   Show below the address map of the S1C17501 internal flash memory.

   map address
	 0x20000 - 0x203ff   sector 0(1KB main block)
	 0x20400 - 0x207ff   sector 1(1KB main block)
	 0x20800 - 0x20bff   sector 2(1KB main block)
	 0x20c00 - 0x20fff   sector 3(1KB main block)
	 0x21000 - 0x213ff   sector 4(1KB main block)
	 0x21400 - 0x217ff   sector 5(1KB main block)
	 0x21800 - 0x21bff   sector 6(1KB main block)
	 0x21c00 - 0x21fff   sector 7(1KB main block)
	 0x22000 - 0x223ff   sector 8(1KB main block)
	 0x22400 - 0x227ff   sector 9(1KB main block)
	 0x22800 - 0x22bff   sector 10(1KB main block)
	 0x22c00 - 0x22fff   sector 11(1KB main block)
	 0x23000 - 0x233ff   sector 12(1KB main block)
	 0x23400 - 0x237ff   sector 13(1KB main block)
	 0x23800 - 0x23bff   sector 14(1KB main block)
	 0x23c00 - 0x23fff   sector 15(1KB main block)
	 0x24000 - 0x243ff   sector 16(1KB main block)
	 0x24400 - 0x247ff   sector 17(1KB main block)
	 0x24800 - 0x24bff   sector 18(1KB main block)
	 0x24c00 - 0x24fff   sector 19(1KB main block)
	 0x25000 - 0x253ff   sector 20(1KB main block)
	 0x25400 - 0x257ff   sector 21(1KB main block)
	 0x25800 - 0x25bff   sector 22(1KB main block)
	 0x25c00 - 0x25fff   sector 23(1KB main block)
	 0x26000 - 0x263ff   sector 24(1KB main block)
	 0x26400 - 0x267ff   sector 25(1KB main block)
	 0x26800 - 0x26bff   sector 26(1KB main block)
	 0x26c00 - 0x26fff   sector 27(1KB main block)
	 0x27000 - 0x273ff   sector 28(1KB main block)
	 0x27400 - 0x277ff   sector 29(1KB main block)
	 0x27800 - 0x27bff   sector 30(1KB main block)
	 0x27c00 - 0x27fff   sector 31(1KB main block)
	 0x28000 - 0x283ff   sector 32(1KB main block)
	 0x28400 - 0x287ff   sector 33(1KB main block)
	 0x28800 - 0x28bff   sector 34(1KB main block)
	 0x28c00 - 0x28fff   sector 35(1KB main block)
	 0x29000 - 0x293ff   sector 36(1KB main block)
	 0x29400 - 0x297ff   sector 37(1KB main block)
	 0x29800 - 0x29bff   sector 38(1KB main block)
	 0x29c00 - 0x29fff   sector 39(1KB main block)
	 0x2a000 - 0x2a3ff   sector 40(1KB main block)
	 0x2a400 - 0x2a7ff   sector 41(1KB main block)
	 0x2a800 - 0x2abff   sector 42(1KB main block)
	 0x2ac00 - 0x2afff   sector 43(1KB main block)
	 0x2b000 - 0x2b3ff   sector 44(1KB main block)
	 0x2b400 - 0x2b7ff   sector 45(1KB main block)
	 0x2b800 - 0x2bbff   sector 46(1KB main block)
	 0x2bc00 - 0x2bfff   sector 47(1KB main block)
	 0x2c000 - 0x2c3ff   sector 48(1KB main block)
	 0x2c400 - 0x2c7ff   sector 49(1KB main block)
	 0x2c800 - 0x2cbff   sector 50(1KB main block)
	 0x2cc00 - 0x2cfff   sector 51(1KB main block)
	 0x2d000 - 0x2d3ff   sector 52(1KB main block)
	 0x2d400 - 0x2d7ff   sector 53(1KB main block)
	 0x2d800 - 0x2dbff   sector 54(1KB main block)
	 0x2dc00 - 0x2dfff   sector 55(1KB main block)
	 0x2e000 - 0x2e3ff   sector 56(1KB main block)
	 0x2e400 - 0x2e7ff   sector 57(1KB main block)
	 0x2e800 - 0x2ebff   sector 58(1KB main block)
	 0x2ec00 - 0x2efff   sector 59(1KB main block)
	 0x2f000 - 0x2f3ff   sector 60(1KB main block)
	 0x2f400 - 0x2f7ff   sector 61(1KB main block)
	 0x2f800 - 0x2fbff   sector 62(1KB main block)
	 0x2fc00 - 0x2ffff   sector 63(1KB main block)
	 0x30000 - 0x303ff   sector 64(1KB main block)
	 0x30400 - 0x307ff   sector 65(1KB main block)
	 0x30800 - 0x30bff   sector 66(1KB main block)
	 0x30c00 - 0x30fff   sector 67(1KB main block)
	 0x31000 - 0x313ff   sector 68(1KB main block)
	 0x31400 - 0x317ff   sector 69(1KB main block)
	 0x31800 - 0x31bff   sector 70(1KB main block)
	 0x31c00 - 0x31fff   sector 71(1KB main block)
	 0x32000 - 0x323ff   sector 72(1KB main block)
	 0x32400 - 0x327ff   sector 73(1KB main block)
	 0x32800 - 0x32bff   sector 74(1KB main block)
	 0x32c00 - 0x32fff   sector 75(1KB main block)
	 0x33000 - 0x333ff   sector 76(1KB main block)
	 0x33400 - 0x337ff   sector 77(1KB main block)
	 0x33800 - 0x33bff   sector 78(1KB main block)
	 0x33c00 - 0x33fff   sector 79(1KB main block)
	 0x34000 - 0x343ff   sector 80(1KB main block)
	 0x34400 - 0x347ff   sector 81(1KB main block)
	 0x34800 - 0x34bff   sector 82(1KB main block)
	 0x34c00 - 0x34fff   sector 83(1KB main block)
	 0x35000 - 0x353ff   sector 84(1KB main block)
	 0x35400 - 0x357ff   sector 85(1KB main block)
	 0x35800 - 0x35bff   sector 86(1KB main block)
	 0x35c00 - 0x35fff   sector 87(1KB main block)
	 0x36000 - 0x363ff   sector 88(1KB main block)
	 0x36400 - 0x367ff   sector 89(1KB main block)
	 0x36800 - 0x36bff   sector 90(1KB main block)
	 0x36c00 - 0x36fff   sector 91(1KB main block)
	 0x37000 - 0x373ff   sector 92(1KB main block)
	 0x37400 - 0x377ff   sector 93(1KB main block)
	 0x37800 - 0x37bff   sector 94(1KB main block)
	 0x37c00 - 0x37fff   sector 95(1KB main block)
	 0x38000 - 0x383ff   sector 96(1KB main block)
	 0x38400 - 0x387ff   sector 97(1KB main block)
	 0x38800 - 0x38bff   sector 98(1KB main block)
	 0x38c00 - 0x38fff   sector 99(1KB main block)
	 0x39000 - 0x393ff   sector 100(1KB main block)
	 0x39400 - 0x397ff   sector 101(1KB main block)
	 0x39800 - 0x39bff   sector 102(1KB main block)
	 0x39c00 - 0x39fff   sector 103(1KB main block)
	 0x3a000 - 0x3a3ff   sector 104(1KB main block)
	 0x3a400 - 0x3a7ff   sector 105(1KB main block)
	 0x3a800 - 0x3abff   sector 106(1KB main block)
	 0x3ac00 - 0x3afff   sector 107(1KB main block)
	 0x3b000 - 0x3b3ff   sector 108(1KB main block)
	 0x3b400 - 0x3b7ff   sector 109(1KB main block)
	 0x3b800 - 0x3bbff   sector 110(1KB main block)
	 0x3bc00 - 0x3bfff   sector 111(1KB main block)
	 0x3c000 - 0x3c3ff   sector 112(1KB main block)
	 0x3c400 - 0x3c7ff   sector 113(1KB main block)
	 0x3c800 - 0x3cbff   sector 114(1KB main block)
	 0x3cc00 - 0x3cfff   sector 115(1KB main block)
	 0x3d000 - 0x3d3ff   sector 116(1KB main block)
	 0x3d400 - 0x3d7ff   sector 117(1KB main block)
	 0x3d800 - 0x3dbff   sector 118(1KB main block)
	 0x3dc00 - 0x3dfff   sector 119(1KB main block)
	 0x3e000 - 0x3e3ff   sector 120(1KB main block)
	 0x3e400 - 0x3e7ff   sector 121(1KB main block)
	 0x3e800 - 0x3ebff   sector 122(1KB main block)
	 0x3ec00 - 0x3efff   sector 123(1KB main block)
	 0x3f000 - 0x3f3ff   sector 124(1KB main block)
	 0x3f400 - 0x3f7ff   sector 125(1KB main block)
	 0x3f800 - 0x3fbff   sector 126(1KB main block)
	 0x3fc00 - 0x3ffff   sector 127(1KB main block)

4. About use in GNU17 Ver.2.x

    [The setting of the flash memory]

        Use the "fls" command to set the flash memory.
        You can do the following chip erasure and write programs by setting flash memory.

        (gdb)c17 fls StartAddr EndAddr ErasePrg WritePrg
            
            StartAddr: Start address of flash memory
            EndAddr: End address of flash memory
            ErasePrg: Start address of erase program
            WritePrg: Start address of write program

        In the case of S1C17501 internal flash memory

            (gdb) c17 fls 0x20000 0x3ffff FLASH_ERASE FLASH_LOAD

        Specify the top address of the flash memory erasure routine for FLASH_ERASE.
        Specify the top address of the flash memory write routine for FLASH_LOAD.

     [The chip erasure of the flash memory]

        Use the "fle" command to erase flash memory by the chip unit.
        By the chip erasure, please specify "0" in "Start Sector" by all means.
	You cannot erase the sector with GDB in S1C17501. 

        (gdb)c17 fle ControlReg StartBlock EndBlock
            
            ControlReg: Start address set by c17 fls
            StartBlock: First block in erase range
            EndBlock: Last block in erase range 

        In the case of S1C17501 internal flash memory

            (gdb) c17 fle 0x20000 0 0

        Note: It is necessary to perform the setting by "fls" command before erasing 
	      flash memory by "fle" commnad. 

    [Program writing to the flash memory]

        Write into the target by the "load" command to write the program in flash memory.

        In the case of writing "sample.elf"

            (gdb) file sample.elf
            (gdb) target icd usb        
            (gdb) load

        Note: It is necessary to perform the setting by "fls" command and the erasure
              of the flash memory before writing flash memory by "load" commnad. 

    [Example of executing flash memory erasure/writing command]
    
	When you load a program in flash memory with gdb, perform it in the following procedures.

        file fls17501.elf                   ; Read the FLS program to the debugger.

        target icd usb                      ; Perform connection with the target to use.

        load                                ; Transfer the FLS program to the RAM of the target board.

        c17 fls 0x20000 0x3ffff FLASH_ERASE FLASH_LOAD
                                            ; You can access flash memory on gdb by performing
											; setting by the fls command.

        c17 fle 0x20000 0 0                 ; With the fle command, erase the flash memory.

        file ***.elf                        ; Read a user's program to the debugger.
        
        target icd usb                      ; Perform connection with the target to use again.

        load                                ; Transfer the program into flash memory.

5. About use in GNU17 Ver.3.x

  5-1)    Connection of S5U1C17001H3(ICDmini3) and target
        Please connect S5U1C17001H3 with the target.
        Please refer to "S5U1C17001H3 User Manual(ICDmini Ver3.0)" for the connection
        procedure.


  5-2)    gdbmini3.ini modification and execution
        Please describe following commands in the debugger (GDB) command file
        "gdbmini3.ini", and execute it.
            - "c17 model_path" and "c17 model" command to specify this directory.
            - "load" command to execute erasing and writing.
        The "gdbmini3.ini" examples are shown below.
        Please refer to "S5U1C17001C Manual(C Compiler Package)" for the debugger
        command, and refer to 5-3) for detail options of "c17 model" command.

        [Ex. 1] VP pin and TARGET_VCC_IN pin are connected.

        ; This directory and the target model are specified.
        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17501
        ; The control of the target begins.
        target icd icdmini3
        ; Flash memory is erased, and a new program is written.
        load
        ; The program will stop at main after execution.
        thbreak main

        [Ex. 2] TARGET_VCC_IN pin is not connected.
        When TARGET_VCC_IN pin is not connected, please specify optional NOVCCIN for
        the c17 model command.

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17501@NOVCCIN
        target icd icdmini3
        load
        thbreak main

        [Ex. 3] TARGET_VCC_IN pin is not connected and resetting target CPU is prohibited.
        To specify two or more options, please delimit them by ",".

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17501@NOVCCIN,NORESET
        target icd icdmini3
        load
        thbreak main

  4-3)    [Detail] options of the c17 model command.
        S1C17501 model supports following options.

    NOVCCIN     Specifies that TARGET_VCC_IN pin of ICDmini3 is not connected.
                [Operation when omitted]
                ICDmini3 communicates with Target CPU by TARGET_VCC_IN voltage level.
                Connection of TARGET_VCC_IN pin and target power suply is necessary.
        Parameter       None

    FLS         Spefifies the FLS proram file.
                [Operation when omitted]
                Standard FLS program file is used.
        Parameter       FLS program file name (*.saf)
        Example         FLS=fwr17501v11.saf    ; Standard FLS program is specified.

    NOREAD      Prohibits the comparison between the writing data and the data written
                in the flash memory.
                [Operation when omitted]
                The writing data is compared with the data written in the flash memory,
                and writing is omitted when equals.
        Parameter       None

    NOWRITE     Prohibits writing in the flash memory.
                [Operation when omitted]
                When the load command of the debugger is executed, data is written in
                the flash memory, except when the writing data equals the written data
                in the flash memory.
        Parameter       None

    NOERASE     Prohibits erasing of the flash memory.
                [Operation when omitted]
                The erase is executed before data is written in the flash memory.
        Parameter       None

    NORESET     Prohibits resetting target CPU when debug begins.
                [Operation when omitted]
                When debug begins, tareget CPU is reset.
        Parameter       None

    BREAKWAIT   Specifies the maximum waiting time [msec] to terminate tareget execution.
                [Operation when omitted]
                Default value (3000msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         BREAKWAIT=3000          ; 3000 [msec] is set.

    TIMEOUT     Specifies the maximum waiting time [msec] when ICDmini3 communicates with
                target MCU.
                [Operation when omitted]
                Default value (10msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         TIMEOUT=10              : 10 [msec] is set.


6. Error code

   Error codes of the FLS program mean as follows.

      0x0 : Finished normally.
      0x1 : Failed in writing / erasure by a verification error.
            Read data from address corresponding to writing / erasure, and compare it 
            with data attempted to write / erase, and the error code returns 
            when they are different.
            At the erasure, compare the data with 0xffff. 
      0x3 : Argument error 1 of erasure command.
      0x4 : Argument error 2 of erasure command. 
      0x5 : Flash memory top address is wrong.
            The error code returns when given top address of flash memory is different
            from actual top address of the flash memory. 


7. Summary of the Flash Writer

    If you use the flash writer function, use "fwr17501v10.saf","fwr17501v11.saf" as 
    Erasure/Writing routine, 
    
    Notes: Please note that the file used by ICD firmware version is different.

    [Setting of data erasure/writing program]

        "fwlp" command is used to specify the program to erase/write flash memory and
        the parameter.
        (gdb)c17 fwlp Filename EraseEntryAddr WriteEntryAddr
        
            Filename: Name of data erase/write program file (Motorola S3 format file)
            EraseEntryAddr: Erase routine entry address
		ICD Firmware V1.0(fwr17501v10.saf)	: 0x44
		Since ICD Firmware V1.1(fwr17501v11.saf): 0x44
            WriteEntryAddr: Write routine entry address
		ICD Firmware V1.0(fwr17501v10.saf)	: 0x78
		Since ICD Firmware V1.1(fwr17501v11.saf): 0x78

    [Setting of data written in flash memory]

        "fwld" command is used to specify the data written in flash memory.
        
        (gdb)c17 fwld Filename EraseStartBlock EraseEndBlock EraseParam
        
            Filename: Name of data file (Motorola S3 format file)
            EraseStartBlock: Block at which to start erasing 
            EraseEndBlock: Block at which to complete erasing 
            EraseParam: Start address of flash memory
    
        In the case of setting flash-writer of S1C17501(Since ICD firmware ver1.1)
        (In the case of chip-erase and writing sample.saf to flash memory)

            (gdb)c17 fwlp fwr17501v11.saf 0x44 0x78
            (gdb)c17 fwld sample.saf 0 0 0x20000 
                
    Note: Please refer to "S5U1C17001C Manual" for the details of the commands.
          Please refer to "S5U1C17001H User Manual" for the execution method of .                   flash-writer.

   Stand-alone flash writer is not supported with S5U1C17001H3(ICDmini3).

8. Others

   8-1)  Copyright
       Except for samples, SEIKO EPSON CORP. holds copyright on all files.
       Don't copy, distribute, or modify copyrighted works without permission. 
       Usage of this program is limited to development or design of product 
       which uses S1C17.

   8-2)  Version up
       Please note that contents may change without prior notice.
       

9.  Revision history
	  Ver 1.0	   Mar. 17, 2008		 - Newly made
      Ver 1.1      Jul. 31, 2015         - Add about use in GNU17 Ver.3.x.

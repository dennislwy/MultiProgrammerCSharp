===============================================================================
    Development tool package for S1C17554 Version 4.30
    dev17554_readme_e.txt
    Aug. 7, 2017
    Copyright (C) SEIKO EPSON CORP. 2015-2017
===============================================================================

Contents
--------
1.  Release history
2.  Outline of package 
3.  Restriction
4.  S5U1C17001C(GNU17) version
5.  How to Use
6.  Others


1. Release history
------------------
  Ver 0.10    Provisional release
  Ver 0.20    fls17554_readme_x.txt corrected.
  Ver 0.30    fls17554_readme_x.txt corrected.
  Ver 0.40    fls17554_readme_x.txt corrected.
  Ver 0.50    It corrected below fls folder. 
              Please refer to readme file of fls of the attachment for details.
  Ver 0.60    fls17554_readme_x.txt corrected.
  Ver 0.70    It corrected below fls folder. 
              Please refer to readme file of fls of the attachment for details.
  Ver 0.80    fls17554_readme_x.txt corrected.
  Ver 0.90    S1C17554.ini file added.
              It corrected below fls folder. 
              Please refer to readme file of fls of the attachment for details.
  Ver 0.91    S1C17554.SPT and parameter.txt file added.
              S1C17554.properties corresponded to GNU17 ver2.0.0.
              fls17554_readme_x.txt corrected.
  Ver 0.92    It corrected below fls folder. 
              Please refer to readme file of fls of the attachment for details.
  Ver 1.00    Formal release.
              It corrected below fls folder. 
              Please refer to readme file of fls of the attachment for details.
  Ver 2.00    S1C17554.properties was corrected.
              S1C17554.cmd was added.
              It corrected below fls folder. 
              Please refer to readme file of fls of the attachment for details.
  Ver 3.00    cfg17554.dll is added.
  Ver 4.00    cfg17554.dll is updated.
              It corrected below fls folder. 
  Ver 4.10    cfg17554.dll was updated for GNU17 v3.1.1.
  Ver 4.20    cfg17554.dll was added for GNU17 v3.0.0-3.1.0.
  Ver 4.30    cfg17554.dll is updated for Multi Programmer Ver4.0.


2. Outline of package 
------------------------------
  This package is files including settings and functions necessary to develop
  S1C17554 on S5U1C17001C(GNU17). 
  Please refer to  [Composition of folder] for the files included in this package.


3. Restriction
--------------
  * When you use GNU17v3

    Please use cfg17xxx.dll that matches to GNU17v3 used. 
    It is necessary to overwrite 17554/cfg17554.dll with cfg17554.dll below the cfg17 folder. 

    - When you use GNU17v3.0.0 or 3.1.0
    Please use cfg17/forGnu17V300-310/cfg17554.dll.

    - When you use GNU17v3.1.1
    Please use cfg17/forGnu17V311/cfg17554.dll.

  * Other restriction

    Please refer to fls17554_readme_j.txt and fls17554_readme_e.txt.


4. S5U1C17001C(GNU17) version
-----------------------------
  Apply to version GNU17 v2.3.0 or later.


5. How to Use
--------------
  [Setting method]
  The folder of 17554 is generated when the this package (zipped archive) file is extracted.
  Please copy the folder under the .../EPSON/GNU17/mcu_model.
  Please restart S5U1C17001C(GNU17) when GNU17 is already launched. 
  When GNU17 starts up, this package is applied.

  [Composition of folder]
  EPSON
   |_ GNU17
        |_ mcu_model
             |_ 17554
                   |_ dev17554_readme_j.txt        Readme file of this package. (Japanese)
                   |_ dev17554_readme_e.txt        Readme file of this package. (English)
                   |_ License_e.txt                License agreement of this package.
                   |_ S1C17554.properties
                   |_ S1C17554.SPT
                   |_ parameter.txt
                   |_ S1C17554.cmd
                   |_ S1C17554.ini
                   |_ cfg17554.dll                 User support library
                   |                               (Default: for GNU17v3.1.1 or later)
                   |_ cfg17                        User support library
                   |   |- forGnu17V300-310         For GNU17v3.0.0-v3.1.0
                   |   |   |_ cfg17554.dll
                   |   |_ forGnu17V311             For GNU17v3.1.1 or later
                   |       |_ cfg17554.dll
                   |
                   |_ fls                          FLS program files for S1C17554.
                       |_ fls17554.elf
                       |_ fls17554_low.elf
                       |_ fls17554_high.elf
                       |_ fwr17554v11.saf
                       |_ fwr17554_lowv11.saf
                       |_ fwr17554_highv11.saf
                       |_ fls17554_readme_j.txt    Readme file of FLS program files.(Japanese)
                       |_ fls17554_readme_e.txt    Readme file of FLS program files.(English)


6. Others
----------
 As to specification of S1C17554, please refer to its technical manual.

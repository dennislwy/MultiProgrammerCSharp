    FLASH READ/WRITE PROGRAMS FOR S1C17554(FLS17554) 

    Jun. 27, 2016

    Copyright (C) SEIKO EPSON CORP. 2015-2016

Contents
================
1) Summary
2) File configuration
3) Summary of the flash memory
3) About use in GNU17 Ver.2.x
4) About use in GNU17 Ver.3.x
6) Error code
7) Summary of the standalone flash writer
8) Limitations
9) Others
10) Revision history
================


1) Summary

   It explains the use of FLS program. 

   The FLS program is a program to perform data writing / erasing
   for the S1C17554 built-in flash memory on debugger(GDB).
   The FLS program works on the built-in RAM.


2) File configuration

   The configuration of this directory is as follows.

   17554
     +  fls
         +  fls17554.elf         FLS program file for S1C17554
                                 (Operating frequency : 8.1 - 16.0MHz)
         +  fls17554_low.elf     (Operating frequency : 4.0 - 8.0MHz)
         +  fls17554_high.elf    (Operating frequency : 6.1 - 24.0MHz)
         +  fwr17554v11.saf      FLS program file for S1C17554
                                 Motorola S3 format file for flash-writer
                                 (Operating frequency : 8.1 - 16.0MHz)
         +  fwr17554_lowv11.saf  (Operating frequency : 4.0 - 8.0MHz)
         +  fwr17554_highv11.saf (Operating frequency : 6.1 - 24.0MHz)
         +  fls17554_readme_j.txt    Readme file(Japanese)
         +  fls17554_readme_e.txt    Readme file(English)


3) Summary of the flash memory

   The summary of the S1C17554 built-in flash memory is as follows.

   Number of sectors :  32 sectors (Size of sector : 4KByte)
   Memory size       :  128KB(64K * 16bit)
   Erasure unit      :  sector unit
   Writing unit      :  word (16bit) unit
   Operation voltage :  Erasure 7.5V
                        Writing 7.0V

   Show below the address map of the S1C17554 built-in flash memory.

   map address
     0x8000 - 0x8fff        sector 0
     0x9000 - 0x9fff        sector 1
     0xa000 - 0xafff        sector 2
     0xb000 - 0xbfff        sector 3
     0xc000 - 0xcfff        sector 4
     0xd000 - 0xdfff        sector 5
     0xe000 - 0xefff        sector 6
     0xf000 - 0xffff        sector 7
     0x10000 - 0x10fff      sector 8
     0x11000 - 0x11fff      sector 9
     0x12000 - 0x12fff      sector 10
     0x13000 - 0x13fff      sector 11
     0x14000 - 0x14fff      sector 12
     0x15000 - 0x15fff      sector 13
     0x16000 - 0x16fff      sector 14
     0x17000 - 0x17fff      sector 15
     0x18000 - 0x18fff      sector 16
     0x19000 - 0x19fff      sector 17
     0x1a000 - 0x1afff      sector 18
     0x1b000 - 0x1bfff      sector 10
     0x1c000 - 0x1cfff      sector 20
     0x1d000 - 0x1dfff      sector 21
     0x1e000 - 0x1efff      sector 22
     0x1f000 - 0x1ffff      sector 23
     0x20000 - 0x20fff      sector 24
     0x21000 - 0x21fff      sector 25
     0x22000 - 0x22fff      sector 26
     0x23000 - 0x23fff      sector 27
     0x24000 - 0x24fff      sector 28
     0x25000 - 0x25fff      sector 29
     0x26000 - 0x26fff      sector 30
     0x27000 - 0x27fff      sector 31


4) About use in GNU17 Ver.2.x

   4-1)  Connection of S5U1C17001H(ICDmini) and user's target board
      When flash memory is erasure or writing, it is necessary to supply 
      the following voltage for flash programming to S1C17554. 
      * Erasure     7.5V
      * Writing     7.0V
      The voltage for flash programming can be controlled 
      by S5U1C17001C(since GNU17 ver2.0) and S5U1C17001H(ICDmini Ver2.0). 

      Please the target where S1C17554 have on board turn on power in the following way. 
      (1) Power on target board.
      (2) Power on S5U1C17001H2.
      (3) The supplied voltage for flash programming is set.
          The SW8 of S5U1C17001H2 is turned on.
      (4) The RESET/START button of S5U1C17001H2 is pushed.
      Please refer to "S5U1C17001H2 User Manual(ICDmini Ver2.0)" for the connection of 
      S5U1C17001H2 and the target board.

      *Notes
      * Please supply voltage for flash programming from the regulated power supply etc.
        When you use S5U1C17001H1(ICDmini Ver1.x). 

      * Please do not supply the voltage to S1C17554 only voltage for flash programming.
        Please supply voltage for flash programming while it supplies power to the target.


   4-2)  The FLS program is selected
      The FLS program prepares the following of each Operating frequency. 

      +  fls
         +  fls17554.elf         Operating frequency : 8.1 - 16.0MHz
         +  fls17554_low.elf     Operating frequency : 4.0 - 8.0MHz
         +  fls17554_high.elf    Operating frequency : 16.1 - 24.0MHz

      When the project of S1C17554 is generated, the following initialization in the 
      command file. 
      In initialization, operating frequency 4MHz - under 16MHz of the FLS program is set. 

      file /cygdrive/C/EPSON/GNU17/mcu_model/17554/fls/fls17554.elf

      target icd usb

      load /cygdrive/C/EPSON/GNU17/mcu_model/17554/fls/fls17554.elf

      Please change the FLS program according to the operating frequency of the target
      used. 
      And, please change passing to GNU17 if necessary. 


   4-3)  The setting of the commands
       Please refer to "S5U1C17001C Manual" for the setting method of the following 
       commands. 


        4-3-1)  The setting of the flash memory
              Use the "fls" command to set the flash memory.
              You can do the following flash memory erasure and write programs by 
              setting flash memory.

              (gdb)c17 fls StartAddr EndAddr ErasePrg WritePrg
            
              StartAddr : Start address of flash memory
              EndAddr   : End address of flash memory
              ErasePrg  : Start address of erase program
              WritePrg  : Start address of write program

              example: When S1C17554 built-in flash memory
                       Preprocessing of the flash memory erasure routine and the flash 
                       memory write routine are set. 
                       (gdb) c17 fls 0x8000 0x27fff FLASH_PREPROGRAM FLASH_LOAD

              FLASH_PREPROGRAM specifies the top address of preprocessing in the flash
               memory erasure routine. 
              FLASH_LOAD specifies the top address in the flash memory write routine. 

              example: When S1C17554 built-in flash memory
                       Sector erase processing of the flash memory erasure routine and 
                       the flash memory write routine are set. 
                       (gdb) c17 fls 0x8000 0x27fff FLASH_SECTORERASE FLASH_LOAD

              FLASH_SECTORERASE specifies the top address of sector erase processing 
              in the flash memory erasure routine. 
              FLASH_LOAD specifies the top address in the flash memory write routine. 


        4-3-2)  The erasure of the flash memory
              Use the "fle" command to erase flash memory by the chip unit.
              Please set the sector number +1 as follows when erase the flash memory all. 

              (gdb)c17 fle ControlReg StartBlock EndBlock

              ControlReg : Start address set by c17 fls
              StartBlock : First block in erase range
              EndBlock   : Last block in erase range 

              example: When S1C17554 built-in flash memory
                       (gdb) c17 fle 0x8000 1 32

              *Notes
              The following settings cannot be done in 1C17554. 
              (gdb) c17 fle 0x8000 0 0


        4-3-3)  Program writing to the flash memory
              Write into the target by the "load" command to write the program in flash
              memory.

              example: When the flash of S1C17554 erase, the voltage for flash 
                       programming is supplied. 
                       (gdb) file sample.elf
                       (gdb) target icd usb
                       (gdb) load sample.psa

              *Note
              Please set user's program.psa when read program information by "load"
              command. 


        4-3-4)  Supply of the voltage for flash programming
             The voltage for flash programming is necessary for S1C17554 at 
             erase/writing flash. 
             "flv" command is used to supply of the voltage for flash programming. 
             "flvs" command is used to stop of the voltage for flash programming. 

              example: When the flash of S1C17554 erase, the voltage for flash
                       programming is supplied.
                       The erase voltage is 7.5V.
                       (gdb) c17 flv 7.5
                       (gdb) c17 fle 0x8000 1 32
                       (gdb) c17 flvs

              example: When the flash of S1C17554 writing, the voltage for flash 
                       programming is supplied.
                       The writing voltage is 7.0V.
                       (gdb) file sample.elf
                       (gdb) target icd usb
                       (gdb) c17 flv 7.0
                       (gdb) load sample.psa
                       (gdb) c17 flvs

              *Note
              The voltage for flash programming is different in each S1C17 model.
              Please supply/stop to the voltage for flash programming only at the time 
              of erase/writing.
              When the voltage for the flash programming supply by the external power, 
              it is not necessary to set this command. 


        4-3-5)  Example of executing flash memory erasure/writing command
             S5U1C17001H2 supply the voltage for the flash programming. 
             When you load a program in flash memory with gdb, perform it in the 
             following procedures.

             file fls17554.elf                   ; Read the FLS program to the debugger.

             target icd usb                      ; Perform connection with the target 
                                                 ; to use.

             load                                ; Transfer the FLS program to the RAM
                                                 ; of the target board.

             c17 fls 0x8000 0x27fff FLASH_PREPROGRAM FLASH_LOAD
                                                 ; It can access flash memory on gdb 
                                                 ;by performing
                                                 ; setting by the fls command.

             c17 flv 7.0                         ; The voltage for flash programming is 
                                                 ; supplied. 
             c17 fle 0x8000 1 32                 ; The erasure of flash memory is
                                                 ; preprocessed by the fle command. 
             c17 flvs                            ; The voltage for flash programming 
                                                 ; is stopped.

             c17 fls 0x8000 0x27fff FLASH_SECTORERASE FLASH_LOAD
                                                 ; It can access flash memory on gdb by
                                                 ; performing
                                                 ; setting by the fls command.

             c17 flv 7.5                         ; The voltage for flash programming is
                                                 ; supplied. 
             c17 fle 0x8000 1 32                 ; With the fle command, erase all the
                                                 ; flash memory.
             c17 flvs                            ; The voltage for flash programming is 
                                                 ; stopped.

             file ***.elf                        ; Read a user's program to the debugger.
                                                 ; Please set ".elf" to the extension of 
                                                 ; the reading file. 

             target icd usb                      ; Perform connection with the target to
                                                 ; use again.

             c17 flv 7.0
             load ***.psa                        ; Transfer the program into flash memory.
             c17 flvs


        4-3-6)  The flash memory erasure/writing command is generated from the template
             The flash memory erasure/writing command can be generated from the model 
             the following procedures. 
                GNU17 IDE -> Project of object -> Properties -> GNU17 GDB Commands ->
                "Create commands from template" -> "Use the command file that depends 
                on machine model" -> Overwrite

             Please change the part of "xxx" such as xxx.elf and xxx.par and xxx.psa to
             the project name of the object. 

5) About use in GNU17 Ver.3.x

  5-1)    Connection of S5U1C17001H3(ICDmini3) and target
        Please connect S5U1C17001H3 with the target.
        Please refer to "S5U1C17001H3 User Manual(ICDmini Ver3.0)" for the connection
        procedure.


  5-2)    gdbmini3.ini modification and execution
        Please describe following commands in the debugger (GDB) command file
        "gdbmini3.ini", and execute it.
            - "c17 model_path" and "c17 model" command to specify this directory.
            - "load" command to execute erasing and writing.
        The "gdbmini3.ini" examples are shown below.
        Please refer to "S5U1C17001C Manual(C Compiler Package)" for the debugger
        command, and refer to 5-3) for detail options of "c17 model" command.

        [Ex. 1] VP pin and TARGET_VCC_IN pin are connected.

        ; This directory and the target model are specified.
        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17554
        ; The control of the target begins.
        target icd icdmini3
        ; Flash memory is erased, and a new program is written.
        load
        ; The program will stop at main after execution.
        thbreak main

        [Ex. 2] TARGET_VCC_IN pin is not connected.
        When TARGET_VCC_IN pin is not connected, please specify optional NOVCCIN for
        the c17 model command.

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17554@NOVCCIN
        target icd icdmini3
        load
        thbreak main

        [Ex. 3] Operating frequency : 16.1 - 24.0MHz.
        Please specify the FLS program.

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17554@FLS=fwr17554_highv11.saf
        target icd icdmini3
        load
        thbreak main

        [Ex. 4] TARGET_VCC_IN pin and Operating frequency : 4.0 - 8.0MHz.
        To specify two or more options, please delimit them by ",".

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17554@FLS=fwr17554_lowv11.saf,NOVCCIN
        target icd icdmini3
        load
        thbreak main


  5-3)    [Detail] options of the c17 model command.
        S1C17554 model supports following options.

    NOVCCIN     Specifies that TARGET_VCC_IN pin of ICDmini3 is not connected.
                [Operation when omitted]
                ICDmini3 communicates with Target CPU by TARGET_VCC_IN voltage level.
                Connection of TARGET_VCC_IN pin and target power supply is necessary.
        Parameter       None

    FLS         Specifies the FLS program file.
                [Operation when omitted]
                Standard FLS program file (Operating frequency :8.1 - 16.0MHz) is used.
        Parameter       FLS program file name (*.saf)
        Example         FLS=fwr17554_highv11.saf ; Operating frequency : 16.1 - 24.0MHz.

    NOREAD      Prohibits the comparison between the writing data and the data written
                in the flash memory.
                [Operation when omitted]
                The writing data is compared with the data written in the flash memory,
                and writing is omitted when equals.
        Parameter       None

    NOWRITE     Prohibits writing in the flash memory.
                [Operation when omitted]
                When the load command of the debugger is executed, data is written in
                the flash memory, except when the writing data equals the written data
                in the flash memory.
        Parameter       None

    NOERASE     Prohibits erasing of the flash memory.
                [Operation when omitted]
                The erase is executed before data is written in the flash memory.
        Parameter       None

    NORESET     Prohibits resetting target CPU when debug begins.
                [Operation when omitted]
                When debug begins, target CPU is reset.
        Parameter       None

    VPP         Sets the erasing and the writing voltage of the flash memory.
                [Operation when omitted]
                The voltage is applied according to the MCU specification 
        Parameter       7.5[V] or 7.0[V]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         VPP=7.5                 ; VPP is 7.5V. 

    SECTOR      Specifies the range of the erasing and writing sectors.
                [Operation when omitted]
                All sectors are included within the range.
        Parameter       begin-end
                        Please set sector number+1 to the value of the begin and the end.
                        Effective sector numbers are defined by another material.
                        When invalid numbers are specified, this option is considered
                        to have been omitted.
        Example         SECTOR=1-10             ; The range of the erasing and writing
                                                ; is from sector 0 to 9.

    BREAKWAIT   Specifies the maximum waiting time [msec] to terminate target execution.
                [Operation when omitted]
                Default value (3000msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         BREAKWAIT=3000          ; 3000 [msec] is set.

    TIMEOUT     Specifies the maximum waiting time [msec] when ICDmini3 communicates with
                target MCU.
                [Operation when omitted]
                Default value (10msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         TIMEOUT=10              : 10 [msec] is set.


6) Error codes

   Error codes of the FLS program mean as follows.

      0x0 : Finished normally.
      0x1 : Failed in writing / erasure by a verification error.
            Read data from address corresponding to writing / erasure, and compare it 
            with data attempted to write / erase, and the error code returns 
            when they are different.
            At the erasure, compare the data with 0xffff. 
      0x3 : Argument error 1 of erasure command.
      0x4 : Argument error 2 of erasure command. 
      0x5 : Flash memory top address is wrong.
            The error code returns when given top address of flash memory is different
            from actual top address of the flash memory. 
      

7) Summary of the standalone flash writer

   S5U1C17001H2 is able to perform stand-alone flash writing onto target without 
   connecting with host.
    The following is a prior setting necessary for the stand-alone flash writer.

   7-1)  The FLS program is selected
      The FLS program prepares the following of each Operating frequency. 

      +  fls
         +  fwr17554v11.saf         Operating frequency : 8.1 - 16.0MHz
         +  fwr17554_lowv11.saf     Operating frequency : 4.1 - 8.0MHz
         +  fwr17554_highv11.saf    Operating frequency : 16.1 - 24.0MHz

      Please use the FLS program according to the operating frequency when use the 
      standalone flash writer.


   7-2)  Setting of the FLS program
      "fwlp" command is used to load the FLS program from host PC to S5U1C17001H. 

       (gdb) c17 fwlp Filename EraseEntryAddr WriteEntryAddr "-vErasePower-WritePower"

       Filename: Name of the FLS program file(This sets according to the operating 
       frequency)
       EraseEntryAddr: Erase routine entry address
       WriteEntryAddr: Write routine entry address
       ErasePower: The voltage for flash programming of erase
       WritePower: The voltage for flash programming of write

       In S1C17554, the voltage for flash programming (VPP) is needed.
       When erase/write is using "-v" option, S5U1C17001H2 can supply a necessary voltage. 

       The following examples, the FLS program for S1C17554 load from the host to 
       S5U1C17001H. 

       example: When S5U1C17001H2 supply the flash programming voltage. 
                And, When erase, the voltage for flash programming is 7.5V. 
                When writing, the voltage for flash programming is 7.0V. 
                (gdb) c17 fwlp fwr17554v11.saf 0xa2 0x6c "-v7.5-7.0"

       example: When the external power supply the flash programming voltage. 
                (gdb) c17 fwlp fwr17554v11.saf 0x36 0x6c

       *Note
       The specified routine address is different according to the Flash programming 
       supply origin. 


   7-3)  Setting of data written in flash memory
        "fwld" command  is used to load the program data to write flash from host PC 
        to S5U1C17001H. 

        (gdb) c17 fwld Filename EraseStartBlock EraseEndBlock EraseParam

         Filename: Name of data file (Motorola S3 format file)
         EraseStartBlock: Block at which to start erasing 
         EraseEndBlock: Block at which to complete erasing 
         EraseParam: Start address of flash memory

        When this command is set, a built-in flash memory of the target is all erased.
        And, specified data file is written. 

        example: When the target is S1C17554 built-in flash memory.
                (gdb) c17 fwld sample.saf 1 32 0x8000


   7-4)  Example of executing flash memory erasure/writing sets command
        It is an example of the command of setting prior of the standalone flash writer
        on debugger (GDB). 

        example: When S5U1C17001H2 supply the flash programming voltage. 
                 c17 fwlp fwr17554v11.saf 0xa2 0x6c "-v7.5-7.0"   
                 ; The FLS program is loaded from host PC to S5U1C17001H.

                 c17 fwld sample.saf 1 32 0x8000                  
                 ; The program data to write flash is loaded from host PC to S5U1C17001H.

        example: When the external power supply the flash programming voltage.
                 c17 fwlp fwr17554v11.saf 0x36 0x6c 
                 ; The FLS program is loaded from host PC to S5U1C17001H.

                 c17 fwld sample.saf 1 32 0x8000
                 ; The program data to write flash is loaded from host PC to S5U1C17001H.

       *Note
       The specified routine address is different according to the Flash programming 
       supply origin. 

   Please refer to "S5U1C17001C Manual" for the details of the commands.
   Please refer to "S5U1C17001H2 User Manual(ICDmini Ver2.0)" for the execution method of 
   the standalone flash-writer.


8) Limitations

   - Stand-alone flash writer is unavailable to target with 4KB or less built-in RAM by 
     firmware version 3.0 or earlier of S5U1C17001H1(ICDmini1),S5U1C17001H2(ICDmini2).
     It becomes available by firmware version 3.1 of S5U1C17001H1(ICDmini1),
     S5U1C17001H2(ICDmini2).
   
  * How to confirm firmware version of S5U1C17001H1(ICDmini1),S5U1C17001H2(ICDmini2)
   Please connect ICDmini1,ICDmini2 with PC and target board, then execute command 
   "target icd usb" on debugger (GDB).
   The version is shown as follows.  

     (gdb) target icd usb
     C17 ICD17 debugging
     Connecting with target (ID_OK)  ..... done
     ICD Initializing (ICD_INITALIZE)  ... done
     Read ICD Version (ICD_VER_READ) ..... done
       ICDmini hardware version .......... 2.0
       ICDmini software version .......... 3.0    <- The firmware version. 
     Debug base address (ID_DATA_READ)  .. xxxx
     Boot address (ICD_DATA_READ) ........ xxxx
     Hardware break MAX .................. x


9) Others

   9-1)  Copyright
       Except for samples, SEIKO EPSON CORP. holds copyright on all files.
       Don't copy, distribute, or modify copyrighted works without permission. 
       Usage of this program is limited to development or design of product 
       which uses S1C17.

   9-2)  Version up
       Please note that contents may change without prior notice.
       

10) Revision history
   Ver 0.1     Sept. 28, 2009        - Newly made
   Ver 0.2     Oct. 06, 2009         - Notes were added to 4-1). The mistake was corrected.
   Ver 0.3     Oct. 23, 2009         - The function of external force break was added to
                                       the limitations. 
   Ver 0.4     Oct. 23, 2009         - Confirm method of firmware version of S5U1C17001H
                                       and Correspondence schedule were added. 
   Ver 0.5     Nov. 24, 2009         - For the renewal number of times of the flash memory decline problem.
   Ver 0.6     Dec. 07, 2009         - Sector setting method of 4-3-2) was corrected. 
   Ver 0.7     Dec. 17, 2009         - Corresponded to Flash writer mode.
   Ver 0.8     Jan. 09, 2010         - The operation method was added to the standalone 
                                       flash writer.
   Ver 0.9     Mar. 08, 2010         - For the renewal number of times of the flash memory decline problem.
                                       The voltage for flash programming was changed.
   Ver 0.91    Mar. 08, 2010         - The description of 4) and 6) corresponded to 
                                       GNU17 ver2.0.0. 
   Ver 0.92    Mar. 30, 2010         - FLASH_PREPROGRAM and FLASH_SECTORERASE label added. 
                                       The description of 4) changed. 
   Ver 1.00    Sept. 16, 2010        - Tedium bit corresponded.
                                       The method of specifying the command of "c17 fle"
                                       is changed. 
                                       Formal release.
   Ver 2.00    Apr. 18, 2011          - Change of address of EraseEntryAddr and
                                       WriteEntryAddr of 6). 
                                       The description of the method of generating the 
                                       command from the template is added to 4). 

   Ver 3.00    Jul. 31, 2015        - Add about use in GNU17 Ver.3.x.
   Ver 4.00    Jun. 27, 2016        - Improvement in constancy of programming.


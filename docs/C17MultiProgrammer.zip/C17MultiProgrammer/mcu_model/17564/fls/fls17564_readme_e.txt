    FLASH READ/WRITE PROGRAMS FOR S1C17564(FLS17564) 

    Jun. 27, 2016

    Copyright (C) SEIKO EPSON CORP. 2011-2016

Contents
================
1) Summary
2) File configuration
3) Summary of the flash memory
4) About use in GNU17 Ver.2.x
5) About use in GNU17 Ver.3.x
6) Error code
7) Summary of the standalone flash writer
8) Limitations
9) Others
10) Revision history
================


1) Summary

   It explains the use of FLS program. 

   The FLS program is a program to perform data writing / erasing
   for the S1C17564 internal flash memory on debugger(GDB).
   The FLS program works on the internal RAM.


2) File configuration

   The configuration of this directory is as follows.

   17564
     +  fls
         +  fls17564.elf         FLS program file for S1C17564
         +  fwr17564v11.saf      FLS program file for S1C17564
                                 (Motorola S3 format file for flash-writer)
         +  fls17564_readme_j.txt    Readme file(Japanese)
         +  fls17564_readme_e.txt    Readme file(English)


3) Summary of the flash memory

   The summary of the S1C17564 internal flash memory is as follows.

   Number of sectors :  32 sectors (Size of sector : 4KByte)
   Memory size       :  128KB(64K * 16bit)
   Erasure unit      :  sector unit
   Writing unit      :  word (16bit) unit
   Operation voltage :  Erasure 7.5V
                        Writing 7.0V

   Show below the address map of the S1C17564 internal flash memory.

   map address
     0x8000 - 0x8fff        sector 0
     0x9000 - 0x9fff        sector 1
     0xa000 - 0xafff        sector 2
     0xb000 - 0xbfff        sector 3
     0xc000 - 0xcfff        sector 4
     0xd000 - 0xdfff        sector 5
     0xe000 - 0xefff        sector 6
     0xf000 - 0xffff        sector 7
     0x10000 - 0x10fff      sector 8
     0x11000 - 0x11fff      sector 9
     0x12000 - 0x12fff      sector 10
     0x13000 - 0x13fff      sector 11
     0x14000 - 0x14fff      sector 12
     0x15000 - 0x15fff      sector 13
     0x16000 - 0x16fff      sector 14
     0x17000 - 0x17fff      sector 15
     0x18000 - 0x18fff      sector 16
     0x19000 - 0x19fff      sector 17
     0x1a000 - 0x1afff      sector 18
     0x1b000 - 0x1bfff      sector 10
     0x1c000 - 0x1cfff      sector 20
     0x1d000 - 0x1dfff      sector 21
     0x1e000 - 0x1efff      sector 22
     0x1f000 - 0x1ffff      sector 23
     0x20000 - 0x20fff      sector 24
     0x21000 - 0x21fff      sector 25
     0x22000 - 0x22fff      sector 26
     0x23000 - 0x23fff      sector 27
     0x24000 - 0x24fff      sector 28
     0x25000 - 0x25fff      sector 29
     0x26000 - 0x26fff      sector 30
     0x27000 - 0x27fff      sector 31


4) About use in GNU17 Ver.2.x

   4-1)  Connection of S5U1C17001H1(ICDmini1)/S5U1C17001H2(ICDmini2) and user's target board
      When flash memory is erasure or writing, it is necessary to supply 
      the following voltage for flash programming to S1C17564. 
      * Erasure     7.5V
      * Writing     7.0V
      The voltage for flash programming can be controlled 
      by S5U1C17001C(since GNU17 ver2.0) and S5U1C17001H2(ICDmini Ver2.0). 

      Please the target where S1C17564 have on board turn on power in the following way. 
      (1) It power on target board.
      (2) It power on S5U1C17001H2.
      (3) The supply of voltage for flash programming is set.
          The SW8 of S5U1C17001H2 is turned on.
      (4) The RESET/START button of S5U1C17001H2 is push.
      Please refer to "S5U1C17001H2 User Manual(ICDmini Ver2.0)" for the connection of S5U1C17001H2 and target board.

      *Notes
      * Please supply the voltage for the flash programming by the external power such as 
        stabilizing supplies when you use S5U1C17001H1(ICDmini Ver1.x). 

      * Please do not supply the voltage to S1C17564 only voltage for flash programming.
        Please supply voltage for flash programming while it supplies power to the target.


   4-2)  The setting of the commands
       Please refer to "S5U1C17001C Manual" for the setting method of the following commands. 


        4-2-1)  The setting of the flash memory
              Use the "fls" command to set the flash memory.
              It can do the following flash memory erasure and write programs by setting flash memory.

              (gdb)c17 fls StartAddr EndAddr ErasePrg WritePrg
            
              StartAddr : Start address of flash memory
              EndAddr   : End address of flash memory
              ErasePrg  : Start address of erase program
              WritePrg  : Start address of write program

              example: When S1C17564 internal flash memory
                       Preprocessing of the flash memory erasure routine and the flash memory write routine are set. 
                       (gdb) c17 fls 0x8000 0x27fff FLASH_PREPROGRAM FLASH_LOAD

              FLASH_PREPROGRAM specifies the top address of preprocessing in the flash memory erasure routine. 
              FLASH_LOAD specifies the top address in the flash memory write routine. 

              example: When S1C17564 built-in flash memory
                       Sector erase processing of the flash memory erasure routine and the flash memory write routine are set. 
                       (gdb) c17 fls 0x8000 0x27fff FLASH_SECTORERASE FLASH_LOAD

              FLASH_SECTORERASE specifies the top address of sector erase processing in the flash memory erasure routine. 
              FLASH_LOAD specifies the top address in the flash memory write routine. 


        4-2-2)  The erasure of the flash memory
              Use the "fle" command to erase flash memory by the chip unit.
              Please set the sector number +1 as follows when erase the flash memory all. 

              (gdb)c17 fle ControlReg StartBlock EndBlock

              ControlReg : Start address set by c17 fls
              StartBlock : First block in erase range
              EndBlock   : Last block in erase range 

              example: When S1C17564 internal flash memory
                       (gdb) c17 fle 0x8000 1 32

              *Notes
              The following settings cannot be done in 1C17564. 
              (gdb) c17 fle 0x8000 0 0


        4-2-3)  Program writing to the flash memory
              Write into the target by the "load" command to write the program in flash memory.

              example: When writing "sample.psa"
                       (gdb) file sample.elf
                       (gdb) target icd usb
                       (gdb) load sample.psa

              *Note
              Please set user's program.psa when read program information by "load" command. 


        4-2-4)  Supply of the voltage for flash programming
             The voltage for flash programming is necessary for S1C17564 at erase/writing flash. 
             "flv" command is used to supply of the voltage for flash programming. 
             "flvs" command is used to stop of the voltage for flash programming. 

              example: When the flash of S1C17564 erase, the voltage for flash programming is supplied.
                       The erase voltage is 7.5V.
                       (gdb) c17 flv 7.5
                       (gdb) c17 fle 0x8000 1 32
                       (gdb) c17 flvs

              example: When the flash of S1C17564 writing, the voltage for flash programming is supplied.
                       The writing voltage is 7.0V.
                       (gdb) file sample.elf
                       (gdb) target icd usb
                       (gdb) c17 flv 7.0
                       (gdb) load sample.psa
                       (gdb) c17 flvs

              *Note
              The voltage for flash programming is different in each S1C17 model.
              Please supply/stop to the voltage for flash programming only at the time of erase/writing. 
              When the voltage for the flash programming supply by the external power, it is not necessary to set this command. 


        4-2-5)  Example of executing flash memory erasure/writing command
             S5U1C17001H2 supply the voltage for the flash programming. 
             When you load a program in flash memory with gdb, perform it in the following procedures.

             file fls17564.elf                   ; Read the FLS program to the debugger.

             target icd usb                      ; Perform connection with the target to use.

             load                                ; Transfer the FLS program to the RAM of the target board.

             c17 fls 0x8000 0x27fff FLASH_PREPROGRAM FLASH_LOAD
                                                 ; It can access flash memory on gdb by performing
                                                 ; setting by the fls command.

             c17 flv 7.0                         ; The voltage for flash programming is supplied. 
             c17 fle 0x8000 1 32                 ; The erasure of flash memory is preprocessed by the fle command. 
             c17 flvs                            ; The voltage for flash programming is stopped.

             c17 fls 0x8000 0x27fff FLASH_SECTORERASE FLASH_LOAD
                                                 ; It can access flash memory on gdb by performing
                                                 ; setting by the fls command

             c17 flv 7.5                         ; The voltage for flash programming is supplied. 
             c17 fle 0x8000 1 32                 ; With the fle command, erase all the flash memory.
             c17 flvs                            ; The voltage for flash programming is stopped.

             file ***.elf                        ; Read a user's program to the debugger.
                                                 ; Please set ".elf" to the extension of the reading file. 

             target icd usb                      ; Perform connection with the target to use again.

             c17 flv 7.0
             load ***.psa                        ; Transfer the program into flash memory.
                                                 ; Please set ".psa" to the extension of the reading file. 
             c17 flvs 


        4-2-6)  The flash memory erasure/writing command is generated from the template
             The flash memory erasure/writing command can be generated from the model the following procedures. 
                GNU17 IDE -> Project of object -> Properties -> GNU17 GDB Commands ->
                "Create commands from template" -> "Use the command file that depends on machine model" -> Overwrite

             Please change the part of "xxx" such as xxx.elf and xxx.par and xxx.psa to the project name of the object. 


5) About use in GNU17 Ver.3.x

  5-1)    Connection of S5U1C17001H3(ICDmini3) and target
        Please connect S5U1C17001H3 with the target.
        Please refer to "S5U1C17001H3 User Manual(ICDmini Ver3.0)" for the connection
        procedure.


  5-2)    gdbmini3.ini modification and execution
        Please describe following commands in the debugger (GDB) command file
        "gdbmini3.ini", and execute it.
            - "c17 model_path" and "c17 model" command to specify this directory.
            - "load" command to execute erasing and writing.
        The "gdbmini3.ini" examples are shown below.
        Please refer to "S5U1C17001C Manual(C Compiler Package)" for the debugger
        command, and refer to 5-3) for detail options of "c17 model" command.

        [Ex. 1] VP pin and TARGET_VCC_IN pin are connected.

        ; This directory and the target model are specified.
        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17564
        ; The control of the target begins.
        target icd icdmini3
        ; Flash memory is erased, and a new program is written.
        load
        ; The program will stop at main after execution.
        thbreak main

        [Ex. 2] TARGET_VCC_IN pin is not connected.
        When TARGET_VCC_IN pin is not connected, please specify optional NOVCCIN for
        the c17 model command.

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17564@NOVCCIN
        target icd icdmini3
        load
        thbreak main

        [Ex. 3] TARGET_VCC_IN pin is not connected and resetting target CPU is prohibited.
        To specify two or more options, please delimit them by ",".

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17564@NOVCCIN,NORESET
        target icd icdmini3
        load
        thbreak main


  5-3)    [Detail] options of the c17 model command.
        S1C17564 model supports following options.

    NOVCCIN     Specifies that TARGET_VCC_IN pin of ICDmini3 is not connected.
                [Operation when omitted]
                ICDmini3 communicates with Target CPU by TARGET_VCC_IN voltage level.
                Connection of TARGET_VCC_IN pin and target power supply is necessary.
        Parameter       None

    FLS         Specifies the FLS program file.
                [Operation when omitted]
                Standard FLS program file is used.
        Parameter       FLS program file name (*.saf)
        Example         FLS=fwr17564v11.saf    ; Standard FLS program is specified.

    NOREAD      Prohibits the comparison between the writing data and the data written
                in the flash memory.
                [Operation when omitted]
                The writing data is compared with the data written in the flash memory,
                and writing is omitted when equals.
        Parameter       None

    NOWRITE     Prohibits writing in the flash memory.
                [Operation when omitted]
                When the load command of the debugger is executed, data is written in
                the flash memory, except when the writing data equals the written data
                in the flash memory.
        Parameter       None

    NOERASE     Prohibits erasing of the flash memory.
                [Operation when omitted]
                The erase is executed before data is written in the flash memory.
        Parameter       None

    NORESET     Prohibits resetting target CPU when debug begins.
                [Operation when omitted]
                When debug begins, target CPU is reset.
        Parameter       None

    VPP         Sets the erasing and the writing voltage of the flash memory.
                [Operation when omitted]
                The voltage is applied according to the MCU specification 
        Parameter       7.5[V] or 7.0[V]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         VPP=7.5                 ; VPP is 7.5V. 

    BREAKWAIT   Specifies the maximum waiting time [msec] to terminate target execution.
                [Operation when omitted]
                Default value (3000msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         BREAKWAIT=3000          ; 3000 [msec] is set.

    TIMEOUT     Specifies the maximum waiting time [msec] when ICDmini3 communicates with
                target MCU.
                [Operation when omitted]
                Default value (10msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         TIMEOUT=10              : 10 [msec] is set.


6) Error code

   The meaning of the error code used by this fls program is as follows.

      0x0 : Erasure was finished normally.
      0x1 : Failed in write/erasure by a verification error.
            Do read of data from the address specified in write/erasure, and compare it
            with the data which specified in write/erasure, and this error code returns
            when there are different.
            At the erasure, compare whether it becomes 0xffff only about the specified address
            (control register or block top address).
      0x2 : It failed in writing. 
            It returns in written when the flash memory is not erased. 
      0x3 : It is out of the range of the number of the sectors which erasure top sectors can set.
      0x4 : It is out of the range of the number of the sectors which erasure terminal sectors can set.
      0x5 : The flash memory first address is different.
            It returns when the top address of the set flash memory and  the top address of an actual flash memory are different. 


7) Summary of the standalone flash writer

   *It is necessary to set it since the firmware version 3.1 of 5U1C17001H1(ICDmini1)/5U1C17001H2(ICDmini2) as follows. 

   When S5U1C17001H1/S5U1C17001H2 don't connect it with host, S5U1C17001H is possible the flash writing in the target by the standalone.
   It explains a prior setting necessary for the standalone flash writer as follows.

   7-1)  Setting of the FLS program
      "fwlp" command is used to load the FLS program from host PC to S5U1C17001H. 

       (gdb) c17 fwlp Filename EraseEntryAddr WriteEntryAddr "-vEraseVoltage-WriteVoltage"

       Filename: Name of the FLS program file
       EraseEntryAddr: Erase routine entry address
       WriteEntryAddr: Write routine entry address
       EraseVoltage: The voltage for flash programming of erase
       WriteVoltage: The voltage for flash programming of write

       In S1C17564, the voltage for flash programming (VPP) is needed.
       When erase/write is using "-v" option, S5U1C17001H2 can supply a necessary voltage. 

       The following examples, the FLS program for S1C17564 load from the host to S5U1C17001H. 

       example: When S5U1C17001H2 supply the flash programming voltage. 
                And, When erase, the voltage for flash programming is 7.5V. 
                When writing, the voltage for flash programming is 7.0V. 
               (gdb) c17 fwlp fwr17654v11.saf 0x9c 0x68 "-v7.5-7.0"

       example: When the external power supply the flash programming voltage. 
               (gdb) c17 fwlp fwr17654v11.saf 0x34 0x68


   7-2)  Setting of data written in flash memory
      "fwld" command  is used to load the program data to write flash from host PC to S5U1C17001H. 

       (gdb) c17 fwld Filename EraseStartBlock EraseEndBlock EraseParam

       Filename: Name of data file (Motorola S3 format file)
       EraseStartBlock: Block at which to start erasing 
       EraseEndBlock: Block at which to complete erasing 
       EraseParam: Start address of flash memory

       When this command is set, a built-in flash memory of the target is all erased.
       And, specified data file is written. 

       example: When the target is S1C17564 built-in flash memory.
               (gdb) c17 fwld sample.saf 1 32 0x8000


   7-3)  Example of executing flash memory erasure/writing sets command
       It is an example of the command of setting prior of the standalone flash writer on debugger (GDB). 

       example: When S5U1C17001H2 supply the flash programming voltage. 
                c17 fwlp fwr17564v11.saf 0x9c 0x68 "-v7.5-7.0" ; The FLS program is
                                                               ; loaded from host PC to S5U1C17001H2.

                c17 fwld sample.saf 1 32 0x8000                ; The program data to write flash is
                                                               ; loaded from host PC to S5U1C17001H2.

       example: When the external power supply the flash programming voltage.
                c17 fwlp fwr17564v11.saf 0x34 0x68             ; The FLS program is
                                                               ; loaded from host PC to S5U1C17001H.

                c17 fwld sample.saf 1 32 0x8000                ; The program data to write flash is
                                                               ; loaded from host PC to S5U1C17001H.

       *Note
       The specified routine address is different according to the Flash programming supply origin. 

   Please refer to "S5U1C17001C Manual" for the details of the commands.
   Please refer to "S5U1C17001H2 User Manual(ICDmini Ver2.0)" for the execution method of 
   the standalone flash writer.

   Stand-alone flash writer is not supported with S5U1C17001H3(ICDmini3).


8) Limitations

   -The function of external force break (BRK IN pin input) cannot be used by S5U1C17001H1/S5U1C17001H2
    of firmware version 2.9 or 2.10. 
    It is a corresponded by firmware version 3.0. 

   *Confirm method of firmware version of S5U1C17001H1/S5U1C17001H2
   Please connect PC with S5U1C17001H and target board. 
   Please execute command "target icd usb" from debugger gdb.
   The version can be confirmed as follows. 

     (gdb) target icd usb
     C17 ICD17 debugging
     Connecting with target (ID_OK)  ..... done
     ICD Initializing (ICD_INITALIZE)  ... done
     Read ICD Version (ICD_VER_READ) ..... done
       ICDmini hardware version .......... 2.0
       ICDmini software version .......... 3.0    <- The version can be confirmed here. 
     Debug base address (ID_DATA_READ)  .. xxxx
     Boot address (ICD_DATA_READ) ........ xxxx
     Hardware break MAX .................. x


9) Others

   9-1)  Copyright
       Except samples, SEIKO EPSON possesses copyright for all files.
       Please do not do a copy, distribution, change without permission.
       In addition, the usage of this program is limited for the development or design of the product which used C17.


   9-2)  Version up
       About the contents, it is changed without a notice at a good time.
       Please understand it.


10) Revision history
   Ver 0.1     Jan. 14, 2010        - Newly made
   Ver 0.2     Mar. 08, 2010        - For the renewal number of times of the flash memory decline problem.
                                      The voltage for flash programming was changed.
   Ver 0.21    Mar. 08, 2010        - The description of 4) and 6) corresponded to GNU17 ver2.0.0.
   Ver 0.3     Mar. 30, 2010        - FLASH_PREPROGRAM and FLASH_SECTORERASE label added. 
                                      The description of 4) changed. 
   Ver 1.00    Nov. 01, 2010        - Tedium bit corresponded.
                                      The method of specifying the command of "c17 fle" is changed. 
                                      Formal release.
   Ver 2.00    Apr. 19, 2011        - FLASH_PREPROGRAM address was changed.
                                      The description of the external power supply use to 4) and 6) was added.
                                      Change of address of EraseEntryAddr and WriteEntryAddr of 6). 
   Ver 2.01    Jul. 27, 2015        - Add about use in GNU17 Ver.3.x.
   Ver 2.02    Jun. 27, 2016        - Improvement in constancy of programming.

   FLASH READ/WRITE PROGRAMS FOR S1C17703(FLS17703) 

   2016.08.04

   Copyright (C) SEIKO EPSON CORP. 2010,2015-2016

Contents
================
1) Summary
2) File configuration
3) Summary of the flash memory
4) About use in GNU17 Ver.2.x
5) About use in GNU17 Ver.3.x
6) Error code
7) Summary of the standalone flash writer
8) Limitations
9) Others
10) Revision history
================

1) Summary

   It explains the use of fls program. 

   The fls program is a program to perform data writing / erasing
   for the S1C17703 built-in flash memory on debugger(GDB).
   The fls program works on the built-in RAM.


2) File configuration

    The configuration of this directory is as follows.

   S1C17703
     +  fls17703.elf    FLS program file for S1C17703
     +  fwr17703v11.saf Motorola S3 format file for flash-writer(Since ICD firmware ver1.1)
     +  readme_j.txt    Readme file(Japanese)
     +  readme_e.txt    Readme file(English)


3) Summary of the flash memory

   The summary of the S1C17703 internal flash memory is as follows.

    Number of sectors :  64 sectors
    Memory size       :  256KB(256K * 16bit)
    Erasure unit      :  chip or sector unit
    writing unit      :  word (16bit) unit
    Read cycle        :  1-5 cycles
    Operation voltage :  read            1.8V - 2.7V
                         Erasure/writing 2.3V - 2.7V

    *Note
    Please refer to "S1C17703 Technical Manual" for Power supply voltage of S1C17703.

    Show below the address map of the S1C17703 internal flash memory.

   map address
         0x08000  - 0x08fff   sector 0(4KB main block)
         0x09000  - 0x09fff   sector 1(4KB main block)
         0x0a000  - 0x0afff   sector 2(4KB main block)
         0x0b000  - 0x0bfff   sector 3(4KB main block)
         0x0c000  - 0x0cfff   sector 4(4KB main block)
         0x0d000  - 0x0dfff   sector 5(4KB main block)
         0x0e000  - 0x0efff   sector 6(4KB main block)
         0x0f000  - 0x0ffff   sector 7(4KB main block)

         0x10000  - 0x10fff   sector 8(4KB main block)
         0x11000  - 0x11fff   sector 9(4KB main block)
         0x12000  - 0x12fff   sector 10(4KB main block)
         0x13000  - 0x13fff   sector 11(4KB main block)
         0x14000  - 0x14fff   sector 12(4KB main block)
         0x15000  - 0x15fff   sector 13(4KB main block)
         0x16000  - 0x16fff   sector 14(4KB main block)
         0x17000  - 0x17fff   sector 15(4KB main block)

         0x18000  - 0x18fff   sector 16(4KB main block)
         0x19000  - 0x19fff   sector 17(4KB main block)
         0x1a000  - 0x1afff   sector 18(4KB main block)
         0x1b000  - 0x1bfff   sector 19(4KB main block)
         0x1c000  - 0x1cfff   sector 20(4KB main block)
         0x1d000  - 0x1dfff   sector 21(4KB main block)
         0x1e000  - 0x1efff   sector 22(4KB main block)
         0x1f000  - 0x1ffff   sector 23(4KB main block)

         0x20000  - 0x20fff   sector 24(4KB main block)
         0x21000  - 0x21fff   sector 25(4KB main block)
         0x22000  - 0x22fff   sector 26(4KB main block)
         0x23000  - 0x23fff   sector 27(4KB main block)
         0x24000  - 0x24fff   sector 28(4KB main block)
         0x25000  - 0x25fff   sector 29(4KB main block)
         0x26000  - 0x26fff   sector 30(4KB main block)
         0x27000  - 0x27fff   sector 31(4KB main block)

         0x28000  - 0x28fff   sector 32(4KB main block)
         0x29000  - 0x29fff   sector 33(4KB main block)
         0x2a000  - 0x2afff   sector 34(4KB main block)
         0x2b000  - 0x2bfff   sector 35(4KB main block)
         0x2c000  - 0x2cfff   sector 36(4KB main block)
         0x2d000  - 0x2dfff   sector 37(4KB main block)
         0x2e000  - 0x2efff   sector 38(4KB main block)
         0x2f000  - 0x2ffff   sector 39(4KB main block)

         0x30000  - 0x30fff   sector 40(4KB main block)
         0x31000  - 0x31fff   sector 41(4KB main block)
         0x32000  - 0x32fff   sector 42(4KB main block)
         0x33000  - 0x33fff   sector 43(4KB main block)
         0x34000  - 0x34fff   sector 44(4KB main block)
         0x35000  - 0x35fff   sector 45(4KB main block)
         0x36000  - 0x36fff   sector 46(4KB main block)
         0x37000  - 0x37fff   sector 47(4KB main block)

         0x38000  - 0x38fff   sector 48(4KB main block)
         0x39000  - 0x39fff   sector 49(4KB main block)
         0x3a000  - 0x3afff   sector 50(4KB main block)
         0x3b000  - 0x3bfff   sector 51(4KB main block)
         0x3c000  - 0x3cfff   sector 52(4KB main block)
         0x3d000  - 0x3dfff   sector 53(4KB main block)
         0x3e000  - 0x3efff   sector 54(4KB main block)
         0x3f000  - 0x3ffff   sector 55(4KB main block)

         0x40000  - 0x40fff   sector 56(4KB main block)
         0x41000  - 0x41fff   sector 57(4KB main block)
         0x42000  - 0x42fff   sector 58(4KB main block)
         0x43000  - 0x43fff   sector 59(4KB main block)
         0x44000  - 0x44fff   sector 60(4KB main block)
         0x45000  - 0x45fff   sector 61(4KB main block)
         0x46000  - 0x46fff   sector 62(4KB main block)
         0x47000  - 0x47fff   sector 63(4KB main block)


4) About use in GNU17 Ver.2.x

   Please refer to "S5U1C17001C Manual" for the setting method of the following commands. 

   4-1)  The setting of the flash memory
      Use the "fls" command to set the flash memory.
      You can do the following flash memory erasure and write programs by setting flash memory.

      (gdb)c17 fls StartAddr EndAddr ErasePrg WritePrg

      StartAddr : Start address of flash memory
      EndAddr   : End address of flash memory
      ErasePrg  : Start address of erase program
      WritePrg  : Start address of write program

      In the case of S1C17703 built-in flash memory

      (gdb) c17 fls 0x8000 0x47fff FLASH_ERASE FLASH_LOAD

      Specify the top address of the flash memory erasure routine for FLASH_ERASE.
      Specify the top address of the flash memory write routine for FLASH_LOAD.


   4-2)  The erasure of the flash memory
      Use the "fle" command to erase flash memory by the chip unit.
      Please set the sector number +1 as follows when erase the flash memory all. 

      (gdb)c17 fle ControlReg StartBlock EndBlock

      ControlReg : Start address set by c17 fls
      StartBlock : First block in erase range
      EndBlock   : Last block in erase range 

      In the case of S1C17703 built-in flash memory

      (gdb) c17 fle 0x8000 0 0


   4-3)  Program writing to the flash memory
      Write into the target by the "load" command to write the program in flash memory.

      In the case of when the flash of S1C17703 erase, the voltage for flash programming is supplied. 

      (gdb) file sample.elf
      (gdb) target icd usb
      (gdb) load


   4-4)  Example of executing flash memory erasure/writing command
      When you load a program in flash memory with gdb, perform it in the following procedures.

      file fls17703.elf                   ; Read the FLS program to the debugger.

      target icd usb                      ; Perform connection with the target to use.

      load                                ; Transfer the FLS program to the RAM of the target board.

      c17 fls 0x8000 0x47fff FLASH_ERASE FLASH_LOAD
                                          ; You can access flash memory on gdb by performing
                                          ; setting by the fls command.

      c17 fle 0x8000 0 0                  ; With the fle command, erase all the flash memory.

      file ***.elf                        ; Read a user's program to the debugger.
                                          ; Please set ".psa" or ".elf" to the extension of the reading file. 

      target icd usb                      ; Perform connection with the target to use again.

      load                                ; Transfer the program into flash memory.


5) About use in GNU17 Ver.3.x

  5-1)    Connection of S5U1C17001H3(ICDmini3) and target
        Please connect S5U1C17001H3 with the target.
        Please refer to "S5U1C17001H3 User Manual(ICDmini Ver3.0)" for the connection
        procedure.


  5-2)    gdbmini3.ini modification and execution
        Please describe following commands in the debugger (GDB) command file
        "gdbmini3.ini", and execute it.
            - "c17 model_path" and "c17 model" command to specify this directory.
            - "load" command to execute erasing and writing.
        The "gdbmini3.ini" examples are shown below.
        Please refer to "S5U1C17001C Manual(C Compiler Package)" for the debugger
        command, and refer to 5-3) for detail options of "c17 model" command.

        [Ex. 1] VP pin and TARGET_VCC_IN pin are connected.

        ; This directory and the target model are specified.
        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17703
        ; The control of the target begins.
        target icd icdmini3
        ; Flash memory is erased, and a new program is written.
        load
        ; The program will stop at main after execution.
        thbreak main

        [Ex. 2] TARGET_VCC_IN pin is not connected.
        When TARGET_VCC_IN pin is not connected, please specify optional NOVCCIN for
        the c17 model command.

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17703@NOVCCIN
        target icd icdmini3
        load
        thbreak main

        [Ex. 3] TARGET_VCC_IN pin is not connected and resetting target CPU is prohibited.
        To specify two or more options, please delimit them by ",".

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17703@NOVCCIN,NORESET
        target icd icdmini3
        load
        thbreak main


  5-3)    [Detail] options of the c17 model command.
        S1C17703 model supports following options.

    NOVCCIN     Specifies that TARGET_VCC_IN pin of ICDmini3 is not connected.
                [Operation when omitted]
                ICDmini3 communicates with Target CPU by TARGET_VCC_IN voltage level.
                Connection of TARGET_VCC_IN pin and target power suply is necessary.
        Parameter       None

    FLS         Spefifies the FLS proram file.
                [Operation when omitted]
                Standard FLS program file is used.
        Parameter       FLS program file name (*.saf)
        Example         FLS=fwr17703v11.saf    ; Standard FLS program is specified.

    NOREAD      Prohibits the comparison between the writing data and the data written
                in the flash memory.
                [Operation when omitted]
                The writing data is compared with the data written in the flash memory,
                and writing is omitted when equals.
        Parameter       None

    NOWRITE     Prohibits writing in the flash memory.
                [Operation when omitted]
                When the load command of the debugger is executed, data is written in
                the flash memory, except when the writing data equals the written data
                in the flash memory.
        Parameter       None

    NOERASE     Prohibits erasing of the flash memory.
                [Operation when omitted]
                The erase is executed before data is written in the flash memory.
        Parameter       None

    NORESET     Prohibits resetting target CPU when debug begins.
                [Operation when omitted]
                When debug begins, tareget CPU is reset.
        Parameter       None

    BREAKWAIT   Specifies the maximum waiting time [msec] to terminate tareget execution.
                [Operation when omitted]
                Default value (3000msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         BREAKWAIT=3000          ; 3000 [msec] is set.

    TIMEOUT     Specifies the maximum waiting time [msec] when ICDmini3 communicates with
                target MCU.
                [Operation when omitted]
                Default value (10msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         TIMEOUT=10              : 10 [msec] is set.


6) Error code

   The meaning of the error code used by this fls program is as follows.
      0x0: Erasure was finished normally.
      0x1: Failed in write/erasure by a verification error.
           Do read of data from the address specified in write/erasure, and compare it
           with the data which specified in write/erasure, and this error code returns
           when there are different.
           At the erasure, compare whether it becomes 0xffff only about the specified address
           (control register or block top address).
      0x3: It is out of the range of the number of the sectors which erasure top sectors can set.
      0x4: It is out of the range of the number of the sectors which erasure terminal sectors can set.
      0x5: Only the flash memory control register changed it.
      0x6: The flash memory control register is not the boundary value of the sector.


7) Summary of the Flash Writer

   When S5U1C17001H1/S5U1C17001H2 don't connect it with host, S5U1C17001H is possible the flash writing in the target by the standalone.
   It explains a prior setting necessary for the standalone flash writer as follows.

   If you use the flash writer function, use "fwr17703v11.saf" as Erasure/Writing routine, 


   7-1) Setting of data erasure/writing program

      "fwlp" command is used to load the data erasure/writing program from host PC to S5U1C17001H. 

       (gdb) c17 fwlp Filename EraseEntryAddr WriteEntryAddr
        
       Filename: Name of data erase/write program file (Motorola S3 format file)
       EraseEntryAddr: Erase routine entry address
       WriteEntryAddr: Write routine entry address

       In the case of data erase/writing program for S1C17703 is loaded from the host to S5U1C17001H

       (gdb) c17 fwlp fwr17703v11.saf 0x108 0x140


   7-2) Setting of data written in flash memory

       "fwld" command  is used to load the program data to write flash from host PC to S5U1C17001H. 

       (gdb) c17 fwld Filename EraseStartBlock EraseEndBlock EraseParam

       Filename: Name of data file (Motorola S3 format file)
       EraseStartBlock: Block at which to start erasing 
       EraseEndBlock: Block at which to complete erasing 
       EraseParam: Start address of flash memory

       When this command is set, a built-in flash memory of the target is all erased.
       And, specified data file is written. 

       In the case of the target is S1C17703 built-in flash memory.
       (In the case of chip-erase and writing sample.saf to flash memory)

       (gdb) c17 fwld sample.saf 0 0 0x8000


   7-3)  Example of executing flash memory erasure/writing sets command
        It is an example of the command of setting prior of the standalone flash writer on debugger (GDB). 

        c17 fwlp fwr17703v11.saf 0x108 0x140             ; The data erasure/writing program is
                                                         ; loaded from host PC to S5U1C17001H.

        c17 fwld sample.saf 0 0 0x8000                   ; The program data to write flash is
                                                         ; loaded from host PC to S5U1C17001H.


   Please refer to "S5U1C17001C Manual" for the details of the commands.
   Please refer to "S5U1C17001H2 User Manual" for the execution method of flash-writer.

   Stand-alone flash writer is not supported with S5U1C17001H3(ICDmini3).


8) Limitations

   None


9) Others

   9-1)  Copyright
       Except samples, SEIKO EPSON possesses copyright for all files.
       Please do not do a copy, distribution, change without permission.
       In addition, the usage of this program is limited for the development or design of the product which used C17.


   9-2)  Version up
       About the contents, it is changed without a notice at a good time.
       Please understand it.


10) Revision history
      Ver 1.0      Apr 13, 2010      - Newly made
      Ver 2.0      Mar 24, 2011      - It corresponded to VDD=2.5-2.7V.
      Ver 2.1      Jul 27, 2015      - Add about use in GNU17 Ver.3.x.
      Ver 2.2      Aug 04, 2016      - Update document.



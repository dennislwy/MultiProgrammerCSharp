    FLASH READ/WRITE PROGRAMS FOR S1C17704(FLS17704) 

        Jul. 31, 2015

        Copyright (C) SEIKO EPSON CORP. 2015


1. Summary

    The fls program of this directory works on the internal RAM, which is a program
    to perform data programing/erasing for the S1C17704 internal flash memory on gdb.


2. File configuration

    The configuration of this directory is as follows.

   S1C17704
     +  fls17704.elf    FLS program file for S1C17704
     +  fwr17704v11.saf Motorola S3 format file for flash-writer(Since ICD firmware ver1.1)
     +  fwr17704v10.saf Motorola S3 format file for flash-writer(ICD firmware ver1.0)
     +  readme_j.txt    Readme file(Japanese)
     +  readme_e.txt    Readme file(English)


3. Summary of the flash memory

   The summary of the S1C17704 internal flash memory is as follows.

    Number of sectors :  16 sectors
    Memory size       :  64KB(32K * 16bit)
    Erasure unit      :  chip or sector unit
    writing unit      :  word (16bit) unit
    Read cycle        :  1-5 cycles
    Operation voltage :  read            1.8V - 2.7V
                         Erasure/writing 2.3V - 2.7V
                         
    Note: Please refer to "S1C17704 Technical Manual" for Power supply voltage of S1C17704.
     
    Show below the address map of the S1C17704 internal flash memory.

   map address
         0x8000  - 0x8fff   sector 0(4KB main block)
         0x9000  - 0x9fff   sector 1(4KB main block)
         0xa000  - 0xafff   sector 2(4KB main block)
         0xb000  - 0xbfff   sector 3(4KB main block)
         0xc000  - 0xcfff   sector 4(4KB main block)
         0xd000  - 0xdfff   sector 5(4KB main block)
         0xe000  - 0xefff   sector 6(4KB main block)
         0xf000  - 0xffff   sector 7(4KB main block)
         0x10000 - 0x10fff  sector 8(4KB main block)
         0x11000 - 0x11fff  sector 9(4KB main block)
         0x12000 - 0x12fff  sector 10(4KB main block)
         0x13000 - 0x13fff  sector 11(4KB main block)
         0x14000 - 0x14fff  sector 12(4KB main block)
         0x15000 - 0x15fff  sector 13(4KB main block)
         0x16000 - 0x16fff  sector 14(4KB main block)
         0x17000 - 0x17fff  sector 15(4KB main block)


4. About use in GNU17 Ver.2.x

    [The setting of the flash memory]

        Use the "fls" command to set the flash memory.
        You can do the following chip erasure and write programs by setting flash memory.

        (gdb)c17 fls StartAddr EndAddr ErasePrg WritePrg
            
            StartAddr: Start address of flash memory
            EndAddr: End address of flash memory
            ErasePrg: Start address of erase program
            WritePrg: Start address of write program
            
        In the case of S1C17704 internal flash memory
        
            (gdb) c17 fls 0x8000 0x17fff FLASH_ERASE FLASH_LOAD 
            
            Specify the top address of the flash memory erasure routine for FLASH_ERASE.
            Specify the top address of the flash memory write routine for FLASH_LOAD.

     [The chip erasure of the flash memory]

        Use the "fle" command to erase flash memory by the chip unit.
        By the chip erasure, please specify "0" in "StartBlock""EndBlock" by all means.
        You cannot erase the sector with GDB in S1C17704. 

        (gdb)c17 fle ControlReg StartBlock EndBlock
            
            ControlReg: Start address set by c17 fls
            StartBlock: First block in erase range
            EndBlock: Last block in erase range 
            
        In the case of S1C17704 internal flash memory
        
            (gdb) c17 fle 0x8000 0 0

        Note: It is necessary to perform the setting by "fls" command before erasing 
	      flash memory by "fle" commnad. 

    [Program writing to the flash memory]

        Write into the target by the "load" command to write the program in flash memory.

        In the case of writing "sample.elf"
        (gdb) file sample.elf
        (gdb) target icd usb        
        (gdb) load

        Note: It is necessary to perform the setting by "fls" command and the erasure
              of the flash memory before writing flash memory by "load" commnad. 

    [operation voltage mode]
        It is necessary to change the operation voltage before operating flash memory 
        in S1C17704.
        It performs a change of the internal operation voltage in the FLS program in
        this FLS,
        It is not necessary to change the internal operation voltage by the user side.

    [Example of executing flash memory erasure/writing command]
    
        When you load a program in flash memory with gdb, perform it in the following
        procedures.

        file fls17704.elf                   ; Read the FLS program to the debugger.

        target icd usb                      ; Perform connection with the target to use.

        load                                ; Transfer the FLS program to the RAM of
                                            ;  the target board.

        c17 fls 0x8000 0x17fff FLASH_ERASE FLASH_LOAD
                                            ; You can access flash memory on gdb
                                            ; by performing
                                            ; setting by the fls command.

        c17 fle 0x8000 0 0                  ; With the fle command, erase the flash memory.

        file ***.elf                        ; Read a user's program to the debugger.
        
        target icd usb                      ; Perform connection with the target to 
                                            ; use again.

        load                                ; Transfer the program into flash memory.

    Note: Please refer to "S5U1C17001C Manual" for the details of the commands.

5. About use in GNU17 Ver.3.x

  5-1)    Connection of S5U1C17001H3(ICDmini3) and target
        Please connect S5U1C17001H3 with the target.
        Please refer to "S5U1C17001H3 User Manual(ICDmini Ver3.0)" for the connection
        procedure.


  5-2)    gdbmini3.ini modification and execution
        Please describe following commands in the debugger (GDB) command file
        "gdbmini3.ini", and execute it.
            - "c17 model_path" and "c17 model" command to specify this directory.
            - "load" command to execute erasing and writing.
        The "gdbmini3.ini" examples are shown below.
        Please refer to "S5U1C17001C Manual(C Compiler Package)" for the debugger
        command, and refer to 5-3) for detail options of "c17 model" command.

        [Ex. 1] VP pin and TARGET_VCC_IN pin are connected.

        ; This directory and the target model are specified.
        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17704
        ; The control of the target begins.
        target icd icdmini3
        ; Flash memory is erased, and a new program is written.
        load
        ; The program will stop at main after execution.
        thbreak main

        [Ex. 2] TARGET_VCC_IN pin is not connected.
        When TARGET_VCC_IN pin is not connected, please specify optional NOVCCIN for
        the c17 model command.

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17704@NOVCCIN
        target icd icdmini3
        load
        thbreak main

        [Ex. 3] TARGET_VCC_IN pin is not connected and resetting target CPU is prohibited.
        To specify two or more options, please delimit them by ",".

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17704@NOVCCIN,NORESET
        target icd icdmini3
        load
        thbreak main

  5-3)    [Detail] options of the c17 model command.
        S1C17704 model supports following options.

    NOVCCIN     Specifies that TARGET_VCC_IN pin of ICDmini3 is not connected.
                [Operation when omitted]
                ICDmini3 communicates with Target CPU by TARGET_VCC_IN voltage level.
                Connection of TARGET_VCC_IN pin and target power suply is necessary.
        Parameter       None

    FLS         Spefifies the FLS proram file.
                [Operation when omitted]
                Standard FLS program file is used.
        Parameter       FLS program file name (*.saf)
        Example         FLS=fwr17704v11.saf    ; Standard FLS program is specified.

    NOREAD      Prohibits the comparison between the writing data and the data written
                in the flash memory.
                [Operation when omitted]
                The writing data is compared with the data written in the flash memory,
                and writing is omitted when equals.
        Parameter       None

    NOWRITE     Prohibits writing in the flash memory.
                [Operation when omitted]
                When the load command of the debugger is executed, data is written in
                the flash memory, except when the writing data equals the written data
                in the flash memory.
        Parameter       None

    NOERASE     Prohibits erasing of the flash memory.
                [Operation when omitted]
                The erase is executed before data is written in the flash memory.
        Parameter       None

    NORESET     Prohibits resetting target CPU when debug begins.
                [Operation when omitted]
                When debug begins, tareget CPU is reset.
        Parameter       None


    BREAKWAIT   Specifies the maximum waiting time [msec] to terminate tareget execution.
                [Operation when omitted]
                Default value (3000msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         BREAKWAIT=3000          ; 3000 [msec] is set.

    TIMEOUT     Specifies the maximum waiting time [msec] when ICDmini3 communicates with
                target MCU.
                [Operation when omitted]
                Default value (10msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         TIMEOUT=10              : 10 [msec] is set.

6. Error code

   Error codes of the FLS program mean as follows.

      0x0 : Finished normally.
      0x1 : Failed in writing / erasure by a verification error.
            Read data from address corresponding to writing / erasure, and compare it 
            with data attempted to write / erase, and the error code returns 
            when they are different.
            At the erasure, compare the data with 0xffff. 
      0x3 : Argument error 1 of erasure command.
      0x4 : Argument error 2 of erasure command. 
      0x5 : Flash memory top address is wrong.
            The error code returns when given top address of flash memory is different
            from actual top address of the flash memory. 

7. Summary of the Flash Writer

    If you use the flash writer function, use "fwr17704v10.saf","fwr17704v11.saf" as 
    Erasure/Writing routine, 
    
    Notes: Please note that the file used by ICD firmware version is different.
    
    [Setting of data erasure/writing program]

        "fwlp" command is used to specify the program to erase/write flash memory and 
        the parameter.
        (gdb)c17 fwlp Filename EraseEntryAddr WriteEntryAddr
        
            Filename: Name of data erase/write program file (Motorola S3 format file)
            EraseEntryAddr: Erase routine entry address
		ICD Firmware V1.0(fwr17704v10.saf)	: 0x4c
		Since ICD Firmware V1.1(fwr17704v11.saf): 0x48
            WriteEntryAddr: Write routine entry address
		ICD Firmware V1.0(fwr17704v10.saf)	: 0x84
		Since ICD Firmware V1.1(fwr17704v11.saf): 0x80

    [Setting of data written in flash memory]

        "fwld" command is used to specify the data written in flash memory.
        
        (gdb)c17 fwld Filename EraseStartBlock EraseEndBlock EraseParam
        
            Filename: Name of data file (Motorola S3 format file)
            EraseStartBlock: Block at which to start erasing 
            EraseEndBlock: Block at which to complete erasing 
            EraseParam: Start address of flash memory
    
        In the case of setting flash-writer of S1C17704(Since ICD firmware ver1.1)
        (In the case of chip-erase and writing sample.saf to flash memory)

            (gdb)c17 fwlp fwr17704v11.saf 0x48 0x80
            (gdb)c17 fwld sample.saf 0 0 0x8000 
                
    Note: Please refer to "S5U1C17001C Manual" for the details of the commands.
          Please refer to "S5U1C17001H User Manual" for the execution method of 
          flash-writer.
   Stand-alone flash writer is not supported with S5U1C17001H3(ICDmini3).

8. Others

   8-1)  Copyright
       Except for samples, SEIKO EPSON CORP. holds copyright on all files.
       Don't copy, distribute, or modify copyrighted works without permission. 
       Usage of this program is limited to development or design of product 
       which uses S1C17.

   8-2)  Version up
       Please note that contents may change without prior notice.
       

9.  Revision history
      About the contents, it is changed without a notice at a good time.
          Please understand it.

    Version up history
      Ver 1.0      Mar 12, 2008      - Newly made

      Ver 1.1      Aug 04, 2009      - fls17704.elf and fwr17704v11.saf are corrected. 
                                       Write and erase became possible to correspond to 
                                       32KHz.
                                       The version of fls17704.elf and fwr17704v11.saf 
                                       were improved to v1.1.
      Ver 1.2      Jul 31, 2015      - Add about use in GNU17 Ver.3.x.

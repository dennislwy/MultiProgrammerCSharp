===============================================================================
    Development tool package for S1C17706 Version 2.40
    dev17706 readme_e.txt
    Aug. 7, 2017
    Copyright (C) SEIKO EPSON CORP. 2011-2017
===============================================================================

Contents
--------
1.  Release history
2.  Outline of package 
3.  Restriction
4.  S5U1C17001C(GNU17) version
5.  How to Use
6.  Others


1. Release history
------------------
  Ver 1.0    Formal release.
  Ver 2.0    cfg17706.dll is added.
  Ver 2.1    cfg17706.dll is changed.
  Ver 2.2    cfg17706.dll was updated for GNU17 v3.1.1.
  Ver 2.3    cfg17706.dll was added for GNU17 v3.0.0-3.1.0.
  Ver 2.4    cfg17.dll is updated for Multi Programmer Ver4.0.


2. Outline of package 
------------------------------
  This package is files including settings and functions necessary to develop
  S1C17706 on S5U1C17001C(GNU17). 
  Please refer to  [Composition of folder] for the files included in this package.


3. Restriction
--------------
  * When you use GNU17v3

    Please use cfg17xxx.dll that matches to GNU17v3 used. 
    It is necessary to overwrite 17706/cfg17706.dll with cfg17706.dll below the cfg17 folder. 

    - When you use GNU17v3.0.0 or 3.1.0
    Please use cfg17/forGnu17V300-310/cfg17706.dll.

    - When you use GNU17v3.1.1
    Please use cfg17/forGnu17V311/cfg17706.dll.

  * Other restriction

    Please refer to fls17706_readme_j.txt and fls17706_readme_e.txt.


4. S5U1C17001C(GNU17) version
-----------------------------
  Apply to version GNU17 v2.3.0 or later.


5. How to Use
--------------
  [Setting method]
  The folder of 17706 is generated when the this package (zipped archive) file is extracted.
  Please copy the folder under the .../EPSON/GNU17/mcu_model.
  Please restart S5U1C17001C(GNU17) when GNU17 is already launched. 
  When GNU17 starts up, this package is applied. 

  [Composition of folder]
  EPSON
   |_ GNU17
        |_ mcu_model
             |_ 17706
                   |_ dev17706_readme_j.txt        Readme file of this package. (Japanese)
                   |_ dev17706_readme_e.txt        Readme file of this package. (English)
                   |_ License_e.txt                License agreement of this package.
                   |_ parameter.txt
                   |_ S1C17706.properties
                   |_ S1C17706.SPT
                   |_ S1C17706.ini
                   |_ cfg17706.dll                 User support library
                   |                               (Default: for GNU17v3.1.1 or later)
                   |_ cfg17                        User support library
                   |   |- forGnu17V300-310         For GNU17v3.0.0-v3.1.0
                   |   |   |_ cfg17706.dll
                   |   |_ forGnu17V311             For GNU17v3.1.1 or later
                   |       |_ cfg17706.dll
                   |
                   |_ fls                          FLS program files for S1C17706.
                       |- fls17706.elf
                       |- fwr17706v11.saf
                       |_ fls17706_readme_j.txt    Readme file of FLS program files.(Japanese)
                       |_ fls17706_readme_e.txt    Readme file of FLS program files.(English)


6. Others
----------
 As to specification of S1C17706, please refer to its technical manual.
   FLASH READ/WRITE PROGRAMS FOR S1C17706(FLS17706) 

   Jul. 31, 2015

   Copyright (C) SEIKO EPSON CORP. 2015

Contents
================
1) Summary
2) File configuration
3) Summary of the flash memory
4) About use in GNU17 Ver.2.x
5) About use in GNU17 Ver.3.x
6) Error code
7) Summary of the standalone flash writer
8) Limitations
9) Others
10) Revision history
================

1) Summary

   It explains the use of fls program. 

   The fls program is a program to perform data writing / erasing
   for the S1C17706 built-in flash memory on debugger(GDB).
   The fls program works on the built-in RAM.


2) File configuration

    The configuration of this directory is as follows.

   S1C17706
     +  fls17706.elf    FLS program file for S1C17706
     +  fwr17706v11.saf Motorola S3 format file for flash-writer(Since ICD firmware ver1.1)
     +  readme_j.txt    Readme file(Japanese)
     +  readme_e.txt    Readme file(English)


3) Summary of the flash memory

   The summary of the S1C17706 internal flash memory is as follows.

    Number of sectors :  257 sectors
    Memory size       :  1MB(1M * 16bit)
    Erasure unit      :  chip or sector unit
    writing unit      :  word (16bit) unit
    Read cycle        :  1-5 cycles
    Operation voltage :  read            1.8V - 2.7V
                         Erasure/writing 2.3V - 2.7V

    *Note
    Please refer to "S1C17706 Technical Manual" for Power supply voltage of S1C17706.

    Show below the address map of the S1C17706 internal flash memory.

   map address
         0x08000  - 0x08fff   sector 0(4KB main block)
         0x09000  - 0x09fff   sector 1(4KB main block)
         0x0a000  - 0x0afff   sector 2(4KB main block)
         0x0b000  - 0x0bfff   sector 3(4KB main block)
         0x0c000  - 0x0cfff   sector 4(4KB main block)
         0x0d000  - 0x0dfff   sector 5(4KB main block)
         0x0e000  - 0x0efff   sector 6(4KB main block)
         0x0f000  - 0x0ffff   sector 7(4KB main block)

         0x10000  - 0x10fff   sector 8(4KB main block)
         0x11000  - 0x11fff   sector 9(4KB main block)
         0x12000  - 0x12fff   sector 10(4KB main block)
         0x13000  - 0x13fff   sector 11(4KB main block)
         0x14000  - 0x14fff   sector 12(4KB main block)
         0x15000  - 0x15fff   sector 13(4KB main block)
         0x16000  - 0x16fff   sector 14(4KB main block)
         0x17000  - 0x17fff   sector 15(4KB main block)

         0x18000  - 0x18fff   sector 16(4KB main block)
         0x19000  - 0x19fff   sector 17(4KB main block)
         0x1a000  - 0x1afff   sector 18(4KB main block)
         0x1b000  - 0x1bfff   sector 19(4KB main block)
         0x1c000  - 0x1cfff   sector 20(4KB main block)
         0x1d000  - 0x1dfff   sector 21(4KB main block)
         0x1e000  - 0x1efff   sector 22(4KB main block)
         0x1f000  - 0x1ffff   sector 23(4KB main block)

         0x20000  - 0x20fff   sector 24(4KB main block)
         0x21000  - 0x21fff   sector 25(4KB main block)
         0x22000  - 0x22fff   sector 26(4KB main block)
         0x23000  - 0x23fff   sector 27(4KB main block)
         0x24000  - 0x24fff   sector 28(4KB main block)
         0x25000  - 0x25fff   sector 29(4KB main block)
         0x26000  - 0x26fff   sector 30(4KB main block)
         0x27000  - 0x27fff   sector 31(4KB main block)

         0x28000  - 0x28fff   sector 32(4KB main block)
         0x29000  - 0x29fff   sector 33(4KB main block)
         0x2a000  - 0x2afff   sector 34(4KB main block)
         0x2b000  - 0x2bfff   sector 35(4KB main block)
         0x2c000  - 0x2cfff   sector 36(4KB main block)
         0x2d000  - 0x2dfff   sector 37(4KB main block)
         0x2e000  - 0x2efff   sector 38(4KB main block)
         0x2f000  - 0x2ffff   sector 39(4KB main block)

         0x30000  - 0x30fff   sector 40(4KB main block)
         0x31000  - 0x31fff   sector 41(4KB main block)
         0x32000  - 0x32fff   sector 42(4KB main block)
         0x33000  - 0x33fff   sector 43(4KB main block)
         0x34000  - 0x34fff   sector 44(4KB main block)
         0x35000  - 0x35fff   sector 45(4KB main block)
         0x36000  - 0x36fff   sector 46(4KB main block)
         0x37000  - 0x37fff   sector 47(4KB main block)

         0x38000  - 0x38fff   sector 48(4KB main block)
         0x39000  - 0x39fff   sector 49(4KB main block)
         0x3a000  - 0x3afff   sector 50(4KB main block)
         0x3b000  - 0x3bfff   sector 51(4KB main block)
         0x3c000  - 0x3cfff   sector 52(4KB main block)
         0x3d000  - 0x3dfff   sector 53(4KB main block)
         0x3e000  - 0x3efff   sector 54(4KB main block)
         0x3f000  - 0x3ffff   sector 55(4KB main block)

         0x40000  - 0x40fff   sector 56(4KB main block)
         0x41000  - 0x41fff   sector 57(4KB main block)
         0x42000  - 0x42fff   sector 58(4KB main block)
         0x43000  - 0x43fff   sector 59(4KB main block)
         0x44000  - 0x44fff   sector 60(4KB main block)
         0x45000  - 0x45fff   sector 61(4KB main block)
         0x46000  - 0x46fff   sector 62(4KB main block)
         0x47000  - 0x47fff   sector 63(4KB main block)

         0x48000  - 0x48fff   sector 64(4KB main block)
         0x49000  - 0x49fff   sector 65(4KB main block)
         0x4a000  - 0x4afff   sector 66(4KB main block)
         0x4b000  - 0x4bfff   sector 67(4KB main block)
         0x4c000  - 0x4cfff   sector 68(4KB main block)
         0x4d000  - 0x4dfff   sector 69(4KB main block)
         0x4e000  - 0x4efff   sector 70(4KB main block)
         0x4f000  - 0x4ffff   sector 71(4KB main block)

         0x50000  - 0x50fff   sector 71(4KB main block)
         0x51000  - 0x51fff   sector 73(4KB main block)
         0x52000  - 0x52fff   sector 74(4KB main block)
         0x53000  - 0x53fff   sector 75(4KB main block)
         0x54000  - 0x54fff   sector 76(4KB main block)
         0x55000  - 0x55fff   sector 77(4KB main block)
         0x56000  - 0x56fff   sector 78(4KB main block)
         0x57000  - 0x57fff   sector 79(4KB main block)

         0x58000  - 0x58fff   sector 80(4KB main block)
         0x59000  - 0x59fff   sector 81(4KB main block)
         0x5a000  - 0x5afff   sector 82(4KB main block)
         0x5b000  - 0x5bfff   sector 83(4KB main block)
         0x5c000  - 0x5cfff   sector 84(4KB main block)
         0x5d000  - 0x5dfff   sector 85(4KB main block)
         0x5e000  - 0x5efff   sector 86(4KB main block)
         0x5f000  - 0x5ffff   sector 87(4KB main block)

         0x60000  - 0x60fff   sector 88(4KB main block)
         0x61000  - 0x61fff   sector 89(4KB main block)
         0x62000  - 0x62fff   sector 90(4KB main block)
         0x63000  - 0x63fff   sector 91(4KB main block)
         0x64000  - 0x64fff   sector 92(4KB main block)
         0x65000  - 0x65fff   sector 93(4KB main block)
         0x66000  - 0x66fff   sector 94(4KB main block)
         0x67000  - 0x67fff   sector 95(4KB main block)

         0x68000  - 0x68fff   sector 96(4KB main block)
         0x69000  - 0x69fff   sector 97(4KB main block)
         0x6a000  - 0x6afff   sector 98(4KB main block)
         0x6b000  - 0x6bfff   sector 99(4KB main block)
         0x6c000  - 0x6cfff   sector 100(4KB main block)
         0x6d000  - 0x6dfff   sector 101(4KB main block)
         0x6e000  - 0x6efff   sector 102(4KB main block)
         0x6f000  - 0x6ffff   sector 103(4KB main block)

         0x70000  - 0x70fff   sector 104(4KB main block)
         0x71000  - 0x71fff   sector 105(4KB main block)
         0x72000  - 0x72fff   sector 106(4KB main block)
         0x73000  - 0x73fff   sector 107(4KB main block)
         0x74000  - 0x74fff   sector 108(4KB main block)
         0x75000  - 0x75fff   sector 109(4KB main block)
         0x76000  - 0x76fff   sector 110(4KB main block)
         0x77000  - 0x77fff   sector 111(4KB main block)

         0x78000  - 0x78fff   sector 112(4KB main block)
         0x79000  - 0x79fff   sector 113(4KB main block)
         0x7a000  - 0x7afff   sector 114(4KB main block)
         0x7b000  - 0x7bfff   sector 115(4KB main block)
         0x7c000  - 0x7cfff   sector 116(4KB main block)
         0x7d000  - 0x7dfff   sector 117(4KB main block)
         0x7e000  - 0x7efff   sector 118(4KB main block)
         0x7f000  - 0x7ffff   sector 119(4KB main block)

         0x80000  - 0x80fff   sector 120(4KB main block)
         0x81000  - 0x81fff   sector 121(4KB main block)
         0x82000  - 0x82fff   sector 122(4KB main block)
         0x83000  - 0x83fff   sector 123(4KB main block)
         0x84000  - 0x84fff   sector 124(4KB main block)
         0x85000  - 0x85fff   sector 125(4KB main block)
         0x86000  - 0x86fff   sector 126(4KB main block)
         0x87000  - 0x87fff   sector 127(4KB main block)

         0x88000  - 0x88fff   sector 128(4KB main block)
         0x89000  - 0x89fff   sector 129(4KB main block)
         0x8a000  - 0x8afff   sector 130(4KB main block)
         0x8b000  - 0x8bfff   sector 131(4KB main block)
         0x8c000  - 0x8cfff   sector 132(4KB main block)
         0x8d000  - 0x8dfff   sector 133(4KB main block)
         0x8e000  - 0x8efff   sector 134(4KB main block)
         0x8f000  - 0x8ffff   sector 135(4KB main block)

         0x90000  - 0x90fff   sector 136(4KB main block)
         0x91000  - 0x91fff   sector 137(4KB main block)
         0x92000  - 0x92fff   sector 138(4KB main block)
         0x93000  - 0x93fff   sector 139(4KB main block)
         0x94000  - 0x94fff   sector 140(4KB main block)
         0x95000  - 0x95fff   sector 141(4KB main block)
         0x96000  - 0x96fff   sector 142(4KB main block)
         0x97000  - 0x97fff   sector 143(4KB main block)

         0x98000  - 0x98fff   sector 144(4KB main block)
         0x99000  - 0x99fff   sector 145(4KB main block)
         0x9a000  - 0x9afff   sector 146(4KB main block)
         0x9b000  - 0x9bfff   sector 147(4KB main block)
         0x9c000  - 0x9cfff   sector 148(4KB main block)
         0x9d000  - 0x9dfff   sector 149(4KB main block)
         0x9e000  - 0x9efff   sector 150(4KB main block)
         0x9f000  - 0x9ffff   sector 151(4KB main block)

         0xa0000  - 0xa0fff   sector 152(4KB main block)
         0xa1000  - 0xa1fff   sector 153(4KB main block)
         0xa2000  - 0xa2fff   sector 154(4KB main block)
         0xa3000  - 0xa3fff   sector 155(4KB main block)
         0xa4000  - 0xa4fff   sector 156(4KB main block)
         0xa5000  - 0xa5fff   sector 157(4KB main block)
         0xa6000  - 0xa6fff   sector 158(4KB main block)
         0xa7000  - 0xa7fff   sector 159(4KB main block)

         0xa8000  - 0xa8fff   sector 160(4KB main block)
         0xa9000  - 0xa9fff   sector 161(4KB main block)
         0xaa000  - 0xaafff   sector 162(4KB main block)
         0xab000  - 0xabfff   sector 163(4KB main block)
         0xac000  - 0xacfff   sector 164(4KB main block)
         0xad000  - 0xadfff   sector 165(4KB main block)
         0xae000  - 0xaefff   sector 166(4KB main block)
         0xaf000  - 0xaffff   sector 167(4KB main block)

         0xb0000  - 0xb0fff   sector 168(4KB main block)
         0xb1000  - 0xb1fff   sector 169(4KB main block)
         0xb2000  - 0xb2fff   sector 170(4KB main block)
         0xb3000  - 0xb3fff   sector 171(4KB main block)
         0xb4000  - 0xb4fff   sector 172(4KB main block)
         0xb5000  - 0xb5fff   sector 173(4KB main block)
         0xb6000  - 0xb6fff   sector 174(4KB main block)
         0xb7000  - 0xb7fff   sector 175(4KB main block)

         0xb8000  - 0xb8fff   sector 176(4KB main block)
         0xb9000  - 0xb9fff   sector 177(4KB main block)
         0xba000  - 0xbafff   sector 178(4KB main block)
         0xbb000  - 0xbbfff   sector 179(4KB main block)
         0xbc000  - 0xbcfff   sector 180(4KB main block)
         0xbd000  - 0xbdfff   sector 181(4KB main block)
         0xbe000  - 0xbefff   sector 182(4KB main block)
         0xbf000  - 0xbffff   sector 183(4KB main block)

         0xc0000  - 0xc0fff   sector 184(4KB main block)
         0xc1000  - 0xc1fff   sector 185(4KB main block)
         0xc2000  - 0xc2fff   sector 186(4KB main block)
         0xc3000  - 0xc3fff   sector 187(4KB main block)
         0xc4000  - 0xc4fff   sector 188(4KB main block)
         0xc5000  - 0xc5fff   sector 189(4KB main block)
         0xc6000  - 0xc6fff   sector 190(4KB main block)
         0xc7000  - 0xc7fff   sector 191(4KB main block)

         0xc8000  - 0xc8fff   sector 192(4KB main block)
         0xc9000  - 0xc9fff   sector 193(4KB main block)
         0xca000  - 0xcafff   sector 194(4KB main block)
         0xcb000  - 0xcbfff   sector 195(4KB main block)
         0xcc000  - 0xccfff   sector 196(4KB main block)
         0xcd000  - 0xcdfff   sector 197(4KB main block)
         0xce000  - 0xcefff   sector 198(4KB main block)
         0xcf000  - 0xcffff   sector 199(4KB main block)

         0xd0000  - 0xd0fff   sector 200(4KB main block)
         0xd1000  - 0xd1fff   sector 201(4KB main block)
         0xd2000  - 0xd2fff   sector 202(4KB main block)
         0xd3000  - 0xd3fff   sector 203(4KB main block)
         0xd4000  - 0xd4fff   sector 204(4KB main block)
         0xd5000  - 0xd5fff   sector 205(4KB main block)
         0xd6000  - 0xd6fff   sector 206(4KB main block)
         0xd7000  - 0xd7fff   sector 207(4KB main block)

         0xd8000  - 0xd8fff   sector 208(4KB main block)
         0xd9000  - 0xd9fff   sector 209(4KB main block)
         0xda000  - 0xdafff   sector 210(4KB main block)
         0xdb000  - 0xdbfff   sector 211(4KB main block)
         0xdc000  - 0xdcfff   sector 212(4KB main block)
         0xdd000  - 0xddfff   sector 213(4KB main block)
         0xde000  - 0xdefff   sector 214(4KB main block)
         0xdf000  - 0xdffff   sector 215(4KB main block)

         0xe0000  - 0xe0fff   sector 216(4KB main block)
         0xe1000  - 0xe1fff   sector 217(4KB main block)
         0xe2000  - 0xe2fff   sector 218(4KB main block)
         0xe3000  - 0xe3fff   sector 219(4KB main block)
         0xe4000  - 0xe4fff   sector 220(4KB main block)
         0xe5000  - 0xe5fff   sector 221(4KB main block)
         0xe6000  - 0xe6fff   sector 222(4KB main block)
         0xe7000  - 0xe7fff   sector 223(4KB main block)

         0xe8000  - 0xe8fff   sector 224(4KB main block)
         0xe9000  - 0xe9fff   sector 225(4KB main block)
         0xea000  - 0xeafff   sector 226(4KB main block)
         0xeb000  - 0xebfff   sector 227(4KB main block)
         0xec000  - 0xecfff   sector 228(4KB main block)
         0xed000  - 0xedfff   sector 229(4KB main block)
         0xee000  - 0xeefff   sector 230(4KB main block)
         0xef000  - 0xeffff   sector 231(4KB main block)

         0xf0000  - 0xf0fff   sector 232(4KB main block)
         0xf1000  - 0xf1fff   sector 234(4KB main block)
         0xf2000  - 0xf2fff   sector 235(4KB main block)
         0xf3000  - 0xf3fff   sector 236(4KB main block)
         0xf4000  - 0xf4fff   sector 237(4KB main block)
         0xf5000  - 0xf5fff   sector 238(4KB main block)
         0xf6000  - 0xf6fff   sector 239(4KB main block)
         0xf7000  - 0xf7fff   sector 240(4KB main block)

         0xf8000  - 0xf8fff   sector 241(4KB main block)
         0xf9000  - 0xf9fff   sector 242(4KB main block)
         0xfa000  - 0xfafff   sector 243(4KB main block)
         0xfb000  - 0xfbfff   sector 244(4KB main block)
         0xfc000  - 0xfcfff   sector 245(4KB main block)
         0xfd000  - 0xfdfff   sector 246(4KB main block)
         0xfe000  - 0xfefff   sector 247(4KB main block)
         0xff000  - 0xfffff   sector 248(4KB main block)

         0x100000  - 0x100fff   sector 249(4KB main block)
         0x101000  - 0x101fff   sector 250(4KB main block)
         0x102000  - 0x102fff   sector 251(4KB main block)
         0x103000  - 0x103fff   sector 252(4KB main block)
         0x104000  - 0x104fff   sector 253(4KB main block)
         0x105000  - 0x105fff   sector 254(4KB main block)
         0x106000  - 0x106fff   sector 255(4KB main block)
         0x107000  - 0x107fff   sector 256(4KB main block)



4) About use in GNU17 Ver.2.x

   Please refer to "S5U1C17001C Manual" for the setting method of the following commands. 

   4-1)  The setting of the flash memory
      Use the "fls" command to set the flash memory.
      You can do the following flash memory erasure and write programs by setting flash
      memory.

      (gdb)c17 fls StartAddr EndAddr ErasePrg WritePrg

      StartAddr : Start address of flash memory
      EndAddr   : End address of flash memory
      ErasePrg  : Start address of erase program
      WritePrg  : Start address of write program

      In the case of S1C17706 built-in flash memory

      (gdb) c17 fls 0x8000 0xffff FLASH_ERASE FLASH_LOAD

      Specify the top address of the flash memory erasure routine for FLASH_ERASE.
      Specify the top address of the flash memory write routine for FLASH_LOAD.


   4-2)  The erasure of the flash memory
      Use the "fle" command to erase flash memory by the chip unit.
      Please set the sector number +1 as follows when erase the flash memory all. 

      (gdb)c17 fle ControlReg StartBlock EndBlock

      ControlReg : Start address set by c17 fls
      StartBlock : First block in erase range
      EndBlock   : Last block in erase range 

      In the case of S1C17706 built-in flash memory

      (gdb) c17 fle 0x8000 0 0


   4-3)  Program writing to the flash memory
      Write into the target by the "load" command to write the program in flash memory.

      In the case of when the flash of S1C17706 erase, the voltage for flash programming 
      is supplied. 

      (gdb) file sample.elf
      (gdb) target icd usb
      (gdb) load


   4-4)  Example of executing flash memory erasure/writing command
      When you load a program in flash memory with gdb, perform it in the following 
      procedures.

      file fls17706.elf                   ; Read the FLS program to the debugger.

      target icd usb                      ; Perform connection with the target to use.

      load                                ; Transfer the FLS program to the RAM of the 
                                          ; target board.

      c17 fls 0x8000 0x107fff FLASH_ERASE FLASH_LOAD
                                          ; You can access flash memory on gdb by 
                                          ; performing setting by the fls command.

      c17 fle 0x8000 0 0                  ; With the fle command, erase all the flash 
                                          ; memory.

      file ***.elf                        ; Read a user's program to the debugger.
                                          ; Please set ".psa" or ".elf" to the extension
                                          ; of the reading file. 

      target icd usb                      ; Perform connection with the target to use
                                          ;  again.

      load                                ; Transfer the program into flash memory.

5) About use in GNU17 Ver.3.x

  5-1)    Connection of S5U1C17001H3(ICDmini3) and target
        Please connect S5U1C17001H3 with the target.
        Please refer to "S5U1C17001H3 User Manual(ICDmini Ver3.0)" for the connection
        procedure.


  5-2)    gdbmini3.ini modification and execution
        Please describe following commands in the debugger (GDB) command file
        "gdbmini3.ini", and execute it.
            - "c17 model_path" and "c17 model" command to specify this directory.
            - "load" command to execute erasing and writing.
        The "gdbmini3.ini" examples are shown below.
        Please refer to "S5U1C17001C Manual(C Compiler Package)" for the debugger
        command, and refer to 5-3) for detail options of "c17 model" command.

        [Ex. 1] VP pin and TARGET_VCC_IN pin are connected.

        ; This directory and the target model are specified.
        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17706
        ; The control of the target begins.
        target icd icdmini3
        ; Flash memory is erased, and a new program is written.
        load
        ; The program will stop at main after execution.
        thbreak main

        [Ex. 2] TARGET_VCC_IN pin is not connected.
        When TARGET_VCC_IN pin is not connected, please specify optional NOVCCIN for
        the c17 model command.

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17706@NOVCCIN
        target icd icdmini3
        load
        thbreak main

        [Ex. 3] TARGET_VCC_IN pin is not connected and resetting target CPU is prohibited.
        To specify two or more options, please delimit them by ",".

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17706@NOVCCIN,NORESET
        target icd icdmini3
        load
        thbreak main


  5-3)    [Detail] options of the c17 model command.
        S1C17706 model supports following options.

    NOVCCIN     Specifies that TARGET_VCC_IN pin of ICDmini3 is not connected.
                [Operation when omitted]
                ICDmini3 communicates with Target CPU by TARGET_VCC_IN voltage level.
                Connection of TARGET_VCC_IN pin and target power suply is necessary.
        Parameter       None

    FLS         Spefifies the FLS proram file.
                [Operation when omitted]
                Standard FLS program file is used.
        Parameter       FLS program file name (*.saf)
        Example         FLS=fwr17706v11.saf    ; Standard FLS program is specified.

    NOREAD      Prohibits the comparison between the writing data and the data written
                in the flash memory.
                [Operation when omitted]
                The writing data is compared with the data written in the flash memory,
                and writing is omitted when equals.
        Parameter       None

    NOWRITE     Prohibits writing in the flash memory.
                [Operation when omitted]
                When the load command of the debugger is executed, data is written in
                the flash memory, except when the writing data equals the written data
                in the flash memory.
        Parameter       None

    NOERASE     Prohibits erasing of the flash memory.
                [Operation when omitted]
                The erase is executed before data is written in the flash memory.
        Parameter       None

    NORESET     Prohibits resetting target CPU when debug begins.
                [Operation when omitted]
                When debug begins, tareget CPU is reset.
        Parameter       None


    BREAKWAIT   Specifies the maximum waiting time [msec] to terminate tareget execution.
                [Operation when omitted]
                Default value (3000msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         BREAKWAIT=3000          ; 3000 [msec] is set.

    TIMEOUT     Specifies the maximum waiting time [msec] when ICDmini3 communicates with
                target MCU.
                [Operation when omitted]
                Default value (10msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         TIMEOUT=10              : 10 [msec] is set.
6) Error code

   Error codes of the FLS program mean as follows.

      0x0 : Finished normally.
      0x1 : Failed in writing / erasure by a verification error.
            Read data from address corresponding to writing / erasure, and compare it 
            with data attempted to write / erase, and the error code returns 
            when they are different.
            At the erasure, compare the data with 0xffff. 
      0x3 : Argument error 1 of erasure command.
      0x4 : Argument error 2 of erasure command. 
      0x5 : Flash memory top address is wrong.
            The error code returns when given top address of flash memory is different
            from actual top address of the flash memory. 

7) Summary of the Flash Writer

   When S5U1C17001H doesn't connect it with host, S5U1C17001H is possible the flash 
   writing in the target by the standalone.
   It explains a prior setting necessary for the standalone flash writer as follows.

   If you use the flash writer function, use "fwr17706v11.saf" as Erasure/Writing routine, 


   7-1) Setting of data erasure/writing program

      "fwlp" command is used to load the data erasure/writing program from host PC to
       S5U1C17001H. 

       (gdb) c17 fwlp Filename EraseEntryAddr WriteEntryAddr
        
       Filename: Name of data erase/write program file (Motorola S3 format file)
       EraseEntryAddr: Erase routine entry address
       WriteEntryAddr: Write routine entry address

       In the case of data erase/writing program for S1C17706 is loaded from the host 
       to S5U1C17001H

       (gdb) c17 fwlp fwr17706v11.saf 0x408 0x440


   7-2) Setting of data written in flash memory

       "fwld" command  is used to load the program data to write flash from host PC to 
       S5U1C17001H. 

       (gdb) c17 fwld Filename EraseStartBlock EraseEndBlock EraseParam

       Filename: Name of data file (Motorola S3 format file)
       EraseStartBlock: Block at which to start erasing 
       EraseEndBlock: Block at which to complete erasing 
       EraseParam: Start address of flash memory

       When this command is set, a built-in flash memory of the target is all erased.
       And, specified data file is written. 

       In the case of the target is S1C17706 built-in flash memory.
       (In the case of chip-erase and writing sample.saf to flash memory)

       (gdb) c17 fwld sample.saf 0 0 0x8000


   7-3)  Example of executing flash memory erasure/writing sets command
        It is an example of the command of setting prior of the standalone flash writer
        on debugger (GDB). 

        c17 fwlp fwr17706v11.saf 0x408 0x440             ; The data erasure/writing 
                                                         ; program is loaded from host
                                                         ; PC to S5U1C17001H.

        c17 fwld sample.saf 0 0 0x8000                   ; The program data to write 
                                                         ; flash isloaded from host PC
                                                         ; to S5U1C17001H.


   Please refer to "S5U1C17001C Manual" for the details of the commands.
   Please refer to "S5U1C17001H User Manual" for the execution method of flash-writer.

   Stand-alone flash writer is not supported with S5U1C17001H3(ICDmini3).

8) Limitations

   None


9) Others

   9-1)  Copyright
       Except for samples, SEIKO EPSON CORP. holds copyright on all files.
       Don't copy, distribute, or modify copyrighted works without permission. 
       Usage of this program is limited to development or design of product 
       which uses S1C17.

   9-2)  Version up
       Please note that contents may change without prior notice.


10) Revision history
      Ver 1.0      Mar 31, 2010      - Newly made
      Ver 2.0      Mar 24, 2011      - It corresponded to VDD=2.5-2.7V.
      Ver 3.0      Jul 31, 2015      - Add about use in GNU17 Ver.3.x.

===============================================================================
    Development tool package for S1C17M32 Version 1.30
    dev17M32 readme_e.txt
    Aug. 7, 2017
    Copyright (C) SEIKO EPSON CORP. 2017
===============================================================================

Contents
--------
1.  Release history
2.  Outline of package 
3.  Restriction
4.  S5U1C17001C(GNU17) version
5.  How to Use
6.  Others

1. Release history
------------------
  Ver 0.10    Provisional release
  Ver 1.00    Formal release
  Ver 1.10    cfg17m32.dll was updated for GNU17 v3.1.1., FLS is changed.
  Ver 1.20    cfg17m32.dll was added for GNU17 v3.0.0-3.1.0.
              cfg17m32.dll and FLS are changed.
  Ver 1.30    cfg17m32.dll is updated for Multi Programmer Ver4.0.


2. Outline of package 
------------------------------
  This package is files including settings and functions necessary to develop
  S1C17M32 on S5U1C17001C(GNU17). 
  Please refer to  [Composition of folder] for the files included in this package.


3. Restriction
--------------
  * When you use GNU17v3

    Please use cfg17xxx.dll that matches to GNU17v3 used. 
    It is necessary to overwrite 17M32/cfg17m32.dll with cfg17m32.dll below the cfg17 folder. 

    - When you use GNU17v3.0.0 or 3.1.0
    Please use cfg17/forGnu17V300-310/cfg17m32.dll.

    - When you use GNU17v3.1.1
    Please use cfg17/forGnu17V311/cfg17m32.dll.

  * Other restriction

    Please refer to fls17M32_readme_j.txt and fls17M32_readme_e.txt.


4. S5U1C17001C(GNU17) version
-----------------------------
  Apply to version GNU17 v2.3.0 or later.


5. How to Use
--------------
  [Setting method]
  The folder of 17M32 is generated when the this package (zipped archive) file is extracted.
  Please copy the folder under the .../EPSON/GNU17/mcu_model.
  Please restart S5U1C17001C(GNU17) when GNU17 is already launched. 
  When GNU17 starts up, this package is applied. 

  [Composition of folder]
  EPSON
   |_ GNU17
        |_ mcu_model
             |_ 17M32
                   |_ dev17M32_readme_j.txt        Readme file of this package. (Japanese)
                   |_ dev17M32_readme_e.txt        Readme file of this package. (English)
                   |_ License_e.txt                License agreement of this package.
                   |_ parameter.txt
                   |_ S1C17M32.properties
                   |_ S1C17M32.ini
                   |_ S1C17M32.SPT
                   |_ usc17M32.dll
                   |_ cfg17m32.dll                 User support library
                   |                               (Default: for GNU17v3.1.1 or later)
                   |_ cfg17                        User support library
                   |   |- forGnu17V300-310         For GNU17v3.0.0-v3.1.0
                   |   |   |_ cfg17m32.dll
                   |   |_ forGnu17V311             For GNU17v3.1.1 or later
                   |       |_ cfg17m32.dll
                   |
                   |_ fls                          FLS program files for S1C17M32.
                       |- fls17M32_2kb.elf
                       |- fls17M32_16b.elf
                       |- fwr17m32_2kbv11.saf
                       |- fwr17m32_16bv11.saf
                       |_ fls17m32_readme_j.txt    Readme file of FLS program files.(Japanese)
                       |_ fls17m32_readme_e.txt    Readme file of FLS program files.(English)


6. Others
----------
 As to specification of S1C17M32, please refer to its technical manual.
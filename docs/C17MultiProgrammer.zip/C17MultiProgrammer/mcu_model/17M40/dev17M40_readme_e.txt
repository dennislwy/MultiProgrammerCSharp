===============================================================================
    Development tool package for S1C17M40
    dev17M40 readme_e.txt
    Jun. 10, 2020
    Copyright (C) SEIKO EPSON CORP. 2020
===============================================================================

Contents
--------
1.  Release history
2.  Outline of package 
3.  Restriction
4.  S5U1C17001C(GNU17) version
5.  How to Use
6.  Others


1. Release history
------------------
  Ver 0.10    Provisional release
  Ver 0.20    cfg17m40.dll was updated (For correspond to the problem of Multi Programming)
  Ver 0.30    Change for ES
  Ver 1.00    Formal release
              FLS changed.
  Ver 1.10    cfg17m40.dll was updated (For correspond to the problem of Multi Programming)
              essim17.ini,essim17_user_def.ini,lcdDisplaySim17M40.dll were added


2. Outline of package 
------------------------------
  This package is files including settings and functions necessary to develop
  S1C17M40 on S5U1C17001C(GNU17). 
  Please refer to  [Composition of folder] for the files included in this package.


3. Restriction
--------------
    Please refer to fls17M40_readme_j.txt and fls17M40_readme_e.txt.


4. S5U1C17001C(GNU17) version
-----------------------------
  Apply to version GNU17 v2.3.0 or later.


5. How to Use
--------------
  [Setting method]
  The folder of 17M40 is generated when the this package (zipped archive) file is extracted.
  Please copy the folder under the .../EPSON/GNU17/mcu_model.
  Please restart S5U1C17001C(GNU17) when GNU17 is already launched. 
  When GNU17 starts up, this package is applied. 

  [Composition of folder]
  EPSON
   |_ GNU17
        |_ mcu_model
             |_ 17M40
                   |_ dev17M40_readme_j.txt        Readme file of this package. (Japanese)
                   |_ dev17M40_readme_e.txt        Readme file of this package. (English)
                   |_ License_e.txt                License agreement of this package.
                   |_ parameter.txt
                   |_ S1C17M40.properties
                   |_ S1C17M40.ini
                   |_ S1C17M40.SPT
                   |- essim17.ini
                   |- essim17_user_def.ini
                   |- lcdDisplaySim17M40.dll
                   |_ usc17M40.dll
                   |_ cfg17M40.dll                 User support library
                   |
                   |_ fls                          FLS program files for S1C17M40.
                       |- fls17M40_2kb.elf
                       |- fls17M40_16b.elf
                       |- fwr17M40_2kbv11.saf
                       |- fwr17M40_16bv11.saf
                       |_ fls17M40_readme_j.txt    Readme file of FLS program files.(Japanese)
                       |_ fls17M40_readme_e.txt    Readme file of FLS program files.(English)


6. Others
----------
 As to specification of S1C17M40, please refer to its technical manual.
===============================================================================
    Development tool package for S1C17W13 Version 1.50
    dev17W13 readme_e.txt
    Aug. 7, 2017
    Copyright (C) SEIKO EPSON CORP. 2017
===============================================================================

Contents
--------
1.  Release history
2.  Outline of package 
3.  Restriction
4.  S5U1C17001C(GNU17) version
5.  How to Use
6.  Others

1. Release history
------------------
  Ver 0.10   Provisional release
  Ver 1.00   S1C17W13.SPT and usc17W13.dll were added.
             Formal release.
  Ver 1.10   cfg17w13.dll is changed.
  Ver 1.20   usc17W13.dll is update.
  Ver 1.30   cfg17w13.dll was updated for GNU17 v3.1.1.
  Ver 1.40   cfg17w13.dll was added for GNU17 v3.0.0-3.1.0.
  Ver 1.50   cfg17w13.dll is updated for Multi Programmer Ver4.0.


2. Outline of package 
------------------------------
  This package is files including settings and functions necessary to develop
  S1C17W13 on S5U1C17001C(GNU17). 
  Please refer to  [Composition of folder] for the files included in this package.


3. Restriction
--------------
  * When you use GNU17v3

    Please use cfg17xxx.dll that matches to GNU17v3 used. 
    It is necessary to overwrite 17W13/cfg17w13.dll with cfg17w13.dll below the cfg17 folder. 

    - When you use GNU17v3.0.0 or 3.1.0
    Please use cfg17/forGnu17V300-310/cfg17w13.dll.

    - When you use GNU17v3.1.1
    Please use cfg17/forGnu17V311/cfg17w13.dll.

  * Other restriction

    Please refer to fls17W13_readme_j.txt and fls17W13_readme_e.txt.


4. S5U1C17001C(GNU17) version
-----------------------------
  Apply to version GNU17 v2.3.0 or later.


5. How to Use
--------------
  [Setting method]
  The folder of 17W13 is generated when the this package (zipped archive) file is extracted.
  Please copy the folder under the .../EPSON/GNU17/mcu_model.
  Please restart S5U1C17001C(GNU17) when GNU17 is already launched. 
  When GNU17 starts up, this package is applied. 

  [Composition of folder]
  EPSON
   |_ GNU17
        |_ mcu_model
             |_ 17W13
                   |_ dev17W13_readme_j.txt        Readme file of this package. (Japanese)
                   |_ dev17W13_readme_e.txt        Readme file of this package. (English)
                   |_ License_e.txt                License agreement of this package.
                   |_ parameter.txt
                   |_ S1C17W13.properties
                   |_ S1C17W13.ini
                   |_ S1C17W13.SPT
                   |_ usc17W13.dll
                   |_ cfg17w13.dll                 User support library
                   |                               (Default: for GNU17v3.1.1 or later)
                   |_ cfg17                        User support library
                   |   |- forGnu17V300-310         For GNU17v3.0.0-v3.1.0
                   |   |   |_ cfg17w13.dll
                   |   |_ forGnu17V311             For GNU17v3.1.1 or later
                   |       |_ cfg17w13.dll
                   |
                   |_ fls                          FLS program files for S1C17W13.
                       |_ fls17W13.elf
                       |_ fwr17W13v11.saf
                       |_ fls17W13_readme_j.txt    Readme file of FLS program files.(Japanese)
                       |_ fls17W13_readme_e.txt    Readme file of FLS program files.(English)


6. Others
----------
 As to specification of S1C17W13, please refer to its technical manual.
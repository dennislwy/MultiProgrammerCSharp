    FLASH READ/WRITE PROGRAMS FOR S1C17W15(FLS17W15) 

    May. 31, 2016

    Copyright (C) SEIKO EPSON CORP. 2015-2016

Contents
================
1) Summary
2) Configuration of files
3) About use in GNU17 Ver.2.x
4) About use in GNU17 Ver.3.x
5) Time required for initial writing / erasure
6) Error codes
7) Summary of stand-alone Flash Writer
8) Limitations
9) Others
10) Revision history
================


1) Summary

   This readme file explains how to use FLS program.

   The FLS program is a program to perform data writing / erasure for the S1C17W15 
   internal flash memory on debugger(GDB).


2) Configuration of files

   The configuration of this directory is as follows.

   17W15
     +  fls
         +  fls17W15.elf         FLS program file for S1C17W15
         +  fwr17W15v11.saf      FLS program file for S1C17W15
                                 (Motorola format file for stand-alone flash writer)
         +  fls17W15_readme_j.txt    Readme file(Japanese)
         +  fls17W15_readme_e.txt    Readme file(English)



3) About use in GNU17 Ver.2.x
   
   3-1)  Connection of S5U1C17001H2(ICDmini2) and user's target board
      When flash memory is erased or written, it is necessary to supply 
      the following voltage for flash programming to S1C17W15. 
      * Erasure     7.5V
      * Writing     7.5V
      The voltage for flash programming can be controlled 
      by S5U1C17001C(GNU17 ver2.0 or later) and S5U1C17001H2(ICDmin Ver2.0). 

      Please turn on the target where S1C17W15 is on board in the following way. 
      (1) Power on target board.
      (2) Power on S5U1C17001H2.
      (3) The supplied voltage for flash programming is set.
          The SW8 of S5U1C17001H2 is turned on.
      (4) The RESET/START button of S5U1C17001H2 is pushed.
      Please refer to "S5U1C17001H2 User Manual(ICDmini Ver2.0)" for the connection of 
      S5U1C17001H2 and the target board.

      *Notes
      * Please supply the external voltage for flash programming only when power is 
        supplied to target.


   3-2)  Commands for flash memory erasure / writing
      S5U1C17001H2 supplys the voltage for flash programming. 
      The followings are commands performed on debugger (GDB) to erase / write flash 
      memory.

      ; Preparation of FLS program 
      
      file fls17W15.elf
      target icd usb
      load fls17W15.elf
      
      ; Erasure
      
      c17 fls 0x8000 0x17fff FLASH_ERASE FLASH_LOAD 128
      c17 flv 7.5
      c17 fle 0x8000 0 0
      c17 flvs
      
      ;Write user program
      
      file ***.elf
      target icd usb
      c17 flv 7.5
      load ***.psa
      c17 flvs 

4) About use in GNU17 Ver.3.x

  4-1)    Connection of S5U1C17001H3(ICDmini3) and target
        Please connect S5U1C17001H3 with the target.
        Please refer to "S5U1C17001H3 User Manual(ICDmini Ver3.0)" for the connection
        procedure.


  4-2)    gdbmini3.ini modification and execution
        Please describe following commands in the debugger (GDB) command file
        "gdbmini3.ini", and execute it.
            - "c17 model_path" and "c17 model" command to specify this directory.
            - "load" command to execute erasing and writing.
        The "gdbmini3.ini" examples are shown below.
        Please refer to "S5U1C17001C Manual(C Compiler Package)" for the debugger
        command, and refer to 4-3) for detail options of "c17 model" command.

        [Ex. 1] VP pin and TARGET_VCC_IN pin are connected.

        ; This directory and the target model are specified.
        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17W15
        ; The control of the target begins.
        target icd icdmini3
        ; Flash memory is erased, and a new program is written.
        load
        ; The program will stop at main after execution.
        thbreak main

        [Ex. 2] TARGET_VCC_IN pin is not connected.
        When TARGET_VCC_IN pin is not connected, please specify optional NOVCCIN for
        the c17 model command.

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17W15@NOVCCIN
        target icd icdmini3
        load
        thbreak main

        [Ex. 3] TARGET_VCC_IN pin is not connected and resetting target CPU is prohibited.
        To specify two or more options, please delimit them by ",".

        c17 model_path c:/EPSON/GNU17V3/mcu_model
        c17 model 17W15@NOVCCIN,NORESET
        target icd icdmini3
        load
        thbreak main


  4-3)    [Detail] options of the c17 model command.
        S1C17W15 model supports following options.

    NOVCCIN     Specifies that TARGET_VCC_IN pin of ICDmini3 is not connected.
                [Operation when omitted]
                ICDmini3 communicates with Target CPU by TARGET_VCC_IN voltage level.
                Connection of TARGET_VCC_IN pin and target power supply is necessary.
        Parameter       None

    FLS         Specifies the FLS program file.
                [Operation when omitted]
                Standard FLS program file is used.
        Parameter       FLS program file name (*.saf)
        Example         FLS=fwr17W15v11.saf    ; Standard FLS program is specified.

    NOREAD      Prohibits the comparison between the writing data and the data written
                in the flash memory.
                [Operation when omitted]
                The writing data is compared with the data written in the flash memory,
                and writing is omitted when equals.
        Parameter       None

    NOWRITE     Prohibits writing in the flash memory.
                [Operation when omitted]
                When the load command of the debugger is executed, data is written in
                the flash memory, except when the writing data equals the written data
                in the flash memory.
        Parameter       None

    NOERASE     Prohibits erasing of the flash memory.
                [Operation when omitted]
                The erase is executed before data is written in the flash memory.
        Parameter       None

    NORESET     Prohibits resetting target CPU when debug begins.
                [Operation when omitted]
                When debug begins, target CPU is reset.
        Parameter       None

    VPP         Sets the erasing and the writing voltage of the flash memory.
                [Operation when omitted]
                The voltage is applied according to the MCU specification 
        Parameter       7.5[V] or 7.0[V]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         VPP=7.5                 ; VPP is 7.5V. 


    BREAKWAIT   Specifies the maximum waiting time [msec] to terminate target execution.
                [Operation when omitted]
                Default value (3000msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         BREAKWAIT=3000          ; 3000 [msec] is set.

    TIMEOUT     Specifies the maximum waiting time [msec] when ICDmini3 communicates with
                target MCU.
                [Operation when omitted]
                Default value (10msec) is set.
        Parameter       from 5 [msec] to 300000 [msec]
                        When an invalid value is specified, this option is considered
                        to have been omitted.
        Example         TIMEOUT=10              : 10 [msec] is set.


5) Time required for initial writing / erasure
      Initial writing: 14 sec (Typical)
      Initial erasure: 11 sec (Typical)
      
      Measurement condition:
        Flash ROM is new.
        External voltage for flash programming is supplied.


6) Error codes

   Error codes of the FLS program mean as follows.

      0x0 : Finished normally.
      0x1 : Failed in writing / erasure by a verification error.
            Read data from address corresponding to writing / erasure, and compare it 
            with data attempted to write / erase, and the error code returns 
            when they are different.
            At the erasure, compare the data with 0xffff. 
      0x3 : Argument error 1 of erasure command.
      0x4 : Argument error 2 of erasure command. 
      0x5 : Flash memory top address is wrong.
            The error code returns when given top address of flash memory is different
            from actual top address of the flash memory. 
      

7) Summary of stand-alone Flash Writer

   S5U1C17001H2 is able to perform stand-alone flash writing onto target without 
   connecting with host.
    The following is a prior setting necessary for the stand-alone flash writer.

   7-1) Commands for setting flash-memory erasure / writing
      Commands for setting on debugger (GDB) prior to performing stand-alone flash 
      writer are as follows. 

      c17 fwlp fwr17W15v11.saf 0x48 0x7c "-v7.5-7.5 -s128"    ; The FLS program is
                                                              ; loaded from host PC to 
                                                              ; S5U1C17001H2.

      c17 fwld sample.saf 0 0 0x8000                          ; The program data to 
                                                              ; write flash is
                                                              ; loaded from host PC to 
                                                              ; S5U1C17001H2.

   Please refer to manual of S5U1C17001H2 on how to perform stand-alone flash writer.

   Stand-alone flash writer is not supported with S5U1C17001H3(ICDmini3).


8) Limitations

   - Stand-alone flash writer is unavailable to target with 4KB or less built-in RAM by 
     firmware version 3.0 or earlier of S5U1C17001H1(ICDmini1),S5U1C17001H2(ICDmini2).
     It becomes available by firmware version 3.1 of S5U1C17001H1(ICDmini1),
     S5U1C17001H2(ICDmini2).
   
  * How to confirm firmware version of S5U1C17001H1(ICDmini1),S5U1C17001H2(ICDmini2)
   Please connect ICDmini1,ICDmini2 with PC and target board, then execute command 
   "target icd usb" on debugger (GDB).
   The version is shown as follows.  

     (gdb) target icd usb
     C17 ICD17 debugging
     Connecting with target (ID_OK)  ..... done
     ICD Initializing (ICD_INITALIZE)  ... done
     Read ICD Version (ICD_VER_READ) ..... done
       ICDmini hardware version .......... 2.0
       ICDmini software version .......... 3.0    <- The firmware version. 
     Debug base address (ID_DATA_READ)  .. xxxx
     Boot address (ICD_DATA_READ) ........ xxxx
     Hardware break MAX .................. x


9) Others

   9-1)  Copyright
       Except for samples, SEIKO EPSON CORP. holds copyright on all files.
       Don't copy, distribute, or modify copyrighted works without permission. 
       Usage of this program is limited to development or design of product 
       which uses S1C17.

   9-2)  Version up
       Please note that contents may change without prior notice.
       

10) Revision history
   Ver 1.00     May. 17, 2013        - Newly made.
   Ver 1.01     May. 29, 2013        - 4) Time required for initial writing / erasure is added.
   Ver 1.10     Nov. 19, 2013        - FLS was corrected. 
   Ver 1.20     Jan. 09, 2014        - Improvement in error recovery.
   Ver 1.30     Apl. 21, 2014        - Improvement in constancy of programming.
   Ver 1.40     Jul. 31, 2015        - Add about use in GNU17 Ver.3.x.
   Ver 1.50     May. 31, 2016        - Improvement in constancy of programming.

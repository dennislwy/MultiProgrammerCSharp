===============================================================================
    Development tool package for S1C17W22 Version 5.80
    dev17W22 readme_e.txt
    Aug. 7, 2017
    Copyright (C) SEIKO EPSON CORP. 2015-2017
===============================================================================

Contents
--------
1.  Release history
2.  About this package 
3.  Restriction
4.  S5U1C17001C(GNU17) version
5.  How to Use
6.  Others


1. Release history
------------------
  Ver 1.00    New release
  Ver 2.00    It corrected below fls folder. 
              Please refer to readme file of fls of the attachment for details.
  Ver 3.00    S1C17W22.SPT file is added.
              It corrected below fls folder. 
              Please refer to readme file of fls of the attachment for details.
  Ver 4.00    S1C17W22.properties file is corrected.
              Communication size specification deletion.
              It corrected below fls folder. 
              Please refer to readme file of fls of the attachment for details.
  Ver 5.00    S1C17W22.properties file and  S1C17W22.SPT file are corrected.
              usc17W22.dll is added.
              Files within fls folder are corrected. 
              Please refer to readme files in the folder in detail.
  Ver 5.10    Files within fls folder are updated.
              usc17W22.dll is updated for GNU17 v2.3.0.
              S1C17W22.SPT is updated for GNU17 v2.3.0.
              ROM size of S1C17W22.properties and parameter.txt is changed. 
  Ver 5.20    Files within fls folder are updated.
  Ver 5.30    cfg17w22.dll is added.
  Ver 5.40    FLS and cfg17w22.dll is changed.
  Ver 5.50    usc17W22.dll is update.
  Ver 5.60    cfg17w22.dll was updated for GNU17 v3.1.1.
  Ver 5.70    cfg17w22.dll was added for GNU17 v3.0.0-3.1.0.
  Ver 5.80    cfg17w22.dll is updated for Multi Programmer Ver4.0.


2. About this package 
------------------------------
  This package is files including settings and functions necessary to develop
  S1C17W22 on S5U1C17001C(GNU17). 
  Please refer to  [Composition of folder] for the files included in this package.


3. Restriction
--------------
  * When you use GNU17v3

    Please use cfg17xxx.dll that matches to GNU17v3 used. 
    It is necessary to overwrite 17W22/cfg17w22.dll with cfg17w22.dll below the cfg17 folder. 

    - When you use GNU17v3.0.0 or 3.1.0
    Please use cfg17/forGnu17V300-310/cfg17w22.dll.

    - When you use GNU17v3.1.1
    Please use cfg17/forGnu17V311/cfg17w22.dll.

  * Other restriction

    Please refer to fls17W22_readme_j.txt and fls17W22_readme_e.txt.


4. S5U1C17001C(GNU17) version
-----------------------------
  Apply to version GNU17 v2.3.0 or later.


5. How to Use
--------------
  [How to apply]
  The folder of 17W22 is generated when the this package (zipped archive) file is extracted.
  Please copy the folder under the .../EPSON/GNU17/mcu_model.
  Please restart S5U1C17001C(GNU17) when GNU17 is already launched. 
  When GNU17 starts up, this package is applied. 

  [Composition of folder]
  EPSON
   |_ GNU17
        |_ mcu_model
             |_ 17W22
                   |_ dev17W22_readme_j.txt        Readme file of this package. (Japanese)
                   |_ dev17W22_readme_e.txt        Readme file of this package. (English)
                   |_ License_e.txt                License agreement of this package.
                   |_ parameter.txt
                   |_ S1C17W22.properties
                   |_ S1C17W22.ini
                   |_ usc17W22.dll
                   |_ S1C17W22.SPT
                   |_ essim17.ini
                   |_ essim17_user_def.ini
                   |_ cfg17w22.dll                 User support library
                   |                               (Default: for GNU17v3.1.1 or later)
                   |_ cfg17                        User support library
                   |   |- forGnu17V300-310         For GNU17v3.0.0-v3.1.0
                   |   |   |_ cfg17w22.dll
                   |   |_ forGnu17V311             For GNU17v3.1.1 or later
                   |       |_ cfg17w22.dll
                   |
                   |_ fls                          FLS program files for S1C17F13.
                       |_ fls17W22.elf
                       |_ fwr17W22v11.saf
                       |_ fls17W22_readme_j.txt    Readme file of FLS program files.(Japanese)
                       |_ fls17W22_readme_e.txt    Readme file of FLS program files.(English)


6. Others
----------
 As to specification of S1C17W22, please refer to its technical manual.
===============================================================================
    Development tool package for S7C17M11 Version 1.40
    devS7C17M11_readme_e.txt
    Aug. 7, 2017
    Copyright (C) SEIKO EPSON CORP. 2016
===============================================================================

Contents
--------
1.  Release history
2.  Outline of package 
3.  Restriction
4.  S5U1C17001C(GNU17) version
5.  How to Use
6.  Others

1. Release history
------------------
  Ver 1.00    New release.
  Ver 1.10    FLS changed.
  Ver 1.20    uscS7C17M11.dll is update.
  Ver 1.30    cfgS7C17M11.dll was updated for GNU17 v3.1.1.
              cfgS7C17M11.dll was added for GNU17 v3.0.0-3.1.0.
  Ver 1.40    cfgS7C17M11.dll is updated for Multi Programmer Ver4.0.


2. Outline of package 
------------------------------
  This package is files including settings and functions necessary to develop
  S7C17M11 on S5U1C17001C(GNU17). 
  Please refer to  [Composition of folder] for the files included in this package.


3. Restriction
--------------
  * When you use GNU17v3

    Please use cfg17xxx.dll that matches to GNU17v3 used. 
    It is necessary to overwrite S7C17M11/cfgS7C17M11.dll with cfgS7C17M11.dll below the cfg17 folder. 

    - When you use GNU17v3.0.0 or 3.1.0
    Please use cfg17/forGnu17V300-310/cfgS7C17M11.dll.

    - When you use GNU17v3.1.1
    Please use cfg17/forGnu17V311/cfgS7C17M11.dll.

  * Other restriction

    Please refer to flsS7C17M11_readme_j.txt and flsS7C17M11_readme_e.txt.


4. S5U1C17001C(GNU17) version
-----------------------------
  Please use the version GNU17 v2.3.0 or later.


5. How to Use
--------------
  [Setting method]
  The folder of S7C17M11 is generated when the this package (zipped archive) file is extracted.
  Please copy the folder under the .../EPSON/GNU17/mcu_model.
  Please restart S5U1C17001C(GNU17) when GNU17 is already launched. 
  When GNU17 starts up, this package is applied. 

  [Composition of folder]
  EPSON
   |_ GNU17
        |_ mcu_model
             |_ S7C17M11
                   |_ devS7C17M11_readme_j.txt        Readme file of this package. (Japanese)
                   |_ devS7C17M11_readme_e.txt        Readme file of this package. (English)
                   |_ License_e.txt                   License agreement of this package.
                   |_ parameter.txt
                   |_ S7C17M11.properties
                   |_ S7C17M11.ini
                   |_ uscS7C17M11.dll
                   |_ S7C17M11.SPT
                   |_ cfgS7C17M11.dll                 User support library
                   |                                  (Default: for GNU17v3.1.1 or later)
                   |_ cfg17                           User support library
                   |   |- forGnu17V300-310            For GNU17v3.0.0-v3.1.0
                   |   |   |_ cfgS7C17M11.dll
                   |   |_ forGnu17V311                For GNU17v3.1.1 or later
                   |       |_ cfgS7C17M11.dll
                   |
                   |- fls                             FLS program files for S7C17M11.
                       |- flsS7C17M11_2kb.elf
                       |- flsS7C17M11_16b.elf
                       |- fwrS7C17M11_2kbv11.saf
                       |- fwrS7C17M11_16bv11.saf
                       |- flsS7C17M11_readme_j.txt    Readme file of FLS program files.(Japanese)
                       |- flsS7C17M11_readme_e.txt    Readme file of FLS program files.(English)


6. Others
----------
 As to specification of S7C17M11, please refer to its technical manual.
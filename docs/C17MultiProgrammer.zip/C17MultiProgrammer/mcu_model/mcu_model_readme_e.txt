===============================================================================
    S1C17 model-specific information tool package for S5U1C17001C
    Aug. 7, 2017
    Copyright (C) SEIKO EPSON CORP. 2017
===============================================================================


Contents
--------
1. Outline
2. Restriction
3. How to Use
4. Composition of folder
5. Release history


1. Outline
---------------------
  This package is S1C17 model-specific information tool for S5U1C17001C (GNU17).
  This package includes MCU model information and functions for developing softwares by GNU17.


2. Restriction
---------------------
  * When you use GNU17v3

    Please use cfg17xxx.dll that matches to GNU17v3 used. 
    It is necessary to overwrite 17xxx/cfg17xxx.dll with cfg17xxx.dll below the cfg17 folder. 
    The default state of 17xxx/cfg17xxx.dll is for GNU17v3.1.1 or later.

    - When you use GNU17v3.0.0 or 3.1.0
    Please use cfg17/forGnu17V300-310/cfg17xxx.dll.

    - When you use GNU17v3.1.1
    Please use cfg17/forGnu17V311/cfg17xxx.dll.


3. How to Use
---------------------
  [Setting method]
  Please extract this package on the folder of .../EPSON/GNU17/.
  The folder of mcu_model is generated under the above folder. 
  Already, please overwrite all when mcu_model exists.
  Please restart S5U1C17001C(GNU17) when GNU17 is already launched. 
  When GNU17 starts up, this package is applied. 

  [Update of model-specific information]
  Separately, when you get model-specific information, please confirm the version of model-specific information.
  And, please overwrite model-specific information. 
  The version of model-specific information can be confirmed in the following parts. 

  - Version written at head of dev17xxx_readme_x.txt included in model-specific information.


4. Composition of folder
---------------------
  This package includes latest each model-specific information at the time of release. 
  Model-specific information and the version included in this package are as follows. 

  EPSON
   |- GNU17
      |- mcu_model
         |- mcu_model_readme_j.txt
         |- mcu_model_readme_e.txt
         |
         |
         |  [model-specific information folder]    [model-specific information version]
         |
         |- 17
         |    |- cfg17
         |    |- fls
         |       ...
         |- 17F13                       (V2.70)
         |- 17F57                       (V1.50)
         |- 17M01                       (V3.80)
         |- 17M10                       (V1.50)
         |- 17M12                       (V1.70)
         |- 17M13                       (V1.70)
         |- 17M30                       (V1.30)
         |- 17M31                       (V1.30)
         |- 17M32                       (V1.30)
         |- 17M33                       (V1.30)
         |- 17M34                       (V1.30)
         |- 17W03                       (V1.60)
         |- 17W04                       (V1.60)
         |- 17W13                       (V1.50)
         |- 17W14                       (V1.60)
         |- 17W15                       (V1.80)
         |- 17W16                       (V1.60)
         |- 17W18                       (V1.70)
         |- 17W22                       (V5.80)
         |- 17W23                       (V1.70)
         |- 17W34                       (V1.40)
         |- 17W35                       (V1.40)
         |- 17W36                       (V1.40)
         |- 17001                       (V2.40)
         |- 17002                       (V2.40)
         |- 17003                       (V2.40)
         |- 17121                       (V2.40)
         |- 17153                       (V3.40)
         |- 17501                       (V2.40)
         |- 17554                       (V4.30)
         |- 17555                       (V1.60)
         |- 17564                       (V2.50)
         |- 17565                       (V1.60)
         |- 17589                       (V1.50)
         |- 17601                       (V2.40)
         |- 17602                       (V1.30)
         |- 17604                       (V2.40)
         |- 17611                       (V2.40)
         |- 17621                       (V4.40)
         |- 17622                       (V3.40)
         |- 17624                       (V2.40)
         |- 17651                       (V10.30)
         |- 17653                       (V9.30)
         |- 17656                       (V1.80)
         |- 17701                       (V2.40)
         |- 17702                       (V1.50)
         |- 17703                       (V2.30)
         |- 17704                       (V2.40)
         |- 17705                       (V2.40)
         |- 17706                       (V2.40)
         |- 17711                       (V2.40)
         |- 17801                       (V2.30)
         |- 17955                       (V1.60)
         |- 17965                       (V1.60)
         |- S7C17M11                    (V1.40)


5. Release history
---------------------
  Ver 1.00     Dec 20, 2013       Created.
  Ver 1.01     Oct 07, 2015       Added the model file.(17589/17656/17955/17965/17W04/17W14/17W16)
  Ver 1.02     Apr 11, 2016       Added the model file.(17W13/17W18)
  Ver 1.03     Nov 30, 2016       Added the model file.(17M10/17W34/17W35/17W36)
  Ver 1.04     Feb 02, 2017       cfg17xxx.dll was updated to operate ICDmini2 on GNU17v3.
  Ver 1.05     Mar 10, 2017       cfg17xxx.dll corresponding to GNU17V3.0.0-3.1.0 was added.
                                  Added the model file.(17M12/17M13/17M30/17M31/17M32/17M33/17M34/S7C17M11)
  Ver 1.06     Aug 07, 2017       cfg17xxx.dll is updated for Multi Programmer Ver4.0.
